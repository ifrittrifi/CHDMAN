/* jni_policy.c -- what Java would answer. Everything not listed gets 0 / false / "" / null and is logged
 * ("JNI call ...") so debug.log shows exactly which calls the engine makes. Keep this file small:
 * only add answers the game really needs. */
#include "jni_fake.h"
#include <string.h>

/* Data paths are relative to the SD card folder chosen by the launcher. */
#define DATA_ROOT "/switch/a8nx64/data"

int jni_policy_int(const char *cls, const char *name, const char *sig, int dflt) {
  if (!strcmp(name, "isNetworkAvailable") || !strcmp(name, "isConnected") || !strcmp(name, "isOnline")) return 0;
  if (!strcmp(name, "getConnectionType")) return 0;         /* no network: engine stays offline */
  if (!strcmp(name, "GetAPILevel")) return 30;
  if (!strcmp(name, "GetIsNeedDownload")) return 0;
  if (!strcmp(name, "GetIsCompleteCheck")) return 1;      /* the engine polls this until "data check complete" */
  /* Only free space is answered: 0 KB made the engine show "not enough free space" and call ExitApplication.
   * Device-tier values (RAM/CPU/screen) stay 0 on purpose: filling them made the engine switch to the
   * models*.jpk/textures*.jpk path (not present on the SD card) and render a black screen. */
  if (!strcmp(name, "GetFreeSpaceInKBytes") || !strcmp(name, "GetFreeSpaceSDInKBytes")) return 16 * 1024 * 1024;   /* 16 GB */
  return dflt;
}
float jni_policy_float(const char *cls, const char *name, const char *sig) { return 0.0f; }
const char *jni_policy_string(const char *cls, const char *name, const char *sig) {
  if (!strcmp(name, "getAbsolutePath") || !strcmp(name, "getFilesDir") || !strcmp(name, "getDataDir")) return DATA_ROOT;
  if (!strcmp(name, "getPackageName")) return "com.gameloft.android.ANMP.GloftA8HM";
  if (!strcmp(name, "getLanguage")) return "en";
  if (!strcmp(name, "getCountry")) return "US";
  if (strstr(name, "PackPath")) return DATA_ROOT "/";
  if (!strncmp(name, "Retrieve", 8)) return !strcmp(name, "RetrieveNativeLibraryPath") ? "/switch/a8nx64/lib" : DATA_ROOT;
  if (!strcmp(name, "GetDeviceManufacturer")) return "Nintendo";
  if (!strcmp(name, "GetDeviceModel") || !strcmp(name, "GetPhoneProduct") || !strcmp(name, "GetPhoneDevice")) return "Switch";
  if (!strcmp(name, "GetCPUAbi")) return "arm64-v8a";
  if (!strcmp(name, "GetFirmware")) return "11";
  if (!strcmp(name, "GetApkPath") || !strcmp(name, "GetApkPathsSingleString")) return "/switch/a8nx64/apk/base.apk";
  if (!strcmp(name, "GetGameName")) return "Asphalt 8";
  if (!strcmp(name, "GetAndroidID") || !strcmp(name, "GetSerial") || !strcmp(name, "GetCPUSerial")) return "0000000000000001";
  return "";
}
