#ifndef DATA_ROOT
#define DATA_ROOT "/switch/a8nx64/data"
#endif
/* jni_fake.c -- JavaVM + JNIEnv built as plain function tables (slot numbers from the JNI spec). */
#include "jni_fake.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef void *(*fn)();
static fn g_env_tab[235], g_vm_tab[8];
static const void *g_env = g_env_tab, *g_vm = g_vm_tab;

typedef struct { const char *name; } jcls_t;
typedef struct { jcls_t *cls; char *name, *sig; } jmeth_t;
static struct { char cls[96], name[64], sig[128]; void *fn; } g_nat[512]; static int g_nnat;

volatile int g_log_off;
/* Buffered log: file stays open, repeated lines are dropped, flushed every 64 lines / on flush call. */
#include <switch.h>
static Mutex g_logmx; static FILE *g_logf; static int g_logn, g_lognew; static char g_last[4][512]; static int g_lastp;
void jni_log_flush(void) { mutexLock(&g_logmx); if (g_logf) fflush(g_logf); mutexUnlock(&g_logmx); }
void jni_log(const char *fmt, ...) {
  if (g_log_off) return;
  va_list a; va_start(a, fmt); char b[512]; vsnprintf(b, sizeof b, fmt, a); va_end(a);
  mutexLock(&g_logmx);
  for (int i = 0; i < 4; i++) if (!strcmp(g_last[i], b)) { mutexUnlock(&g_logmx); return; }
  strcpy(g_last[g_lastp++ & 3], b);
  if (!g_logf) { mkdir("/switch/a8nx64", 0777); g_logf = fopen("/switch/a8nx64/debug.log", "a"); if (!g_logf) g_logf = stderr; setvbuf(g_logf, NULL, _IOFBF, 1 << 16); }
  if (++g_logn < 30000 || strstr(b, "xception") || strstr(b, "FATAL") || strstr(b, "exit")) {
    fprintf(g_logf, "%s\n", b);
    if (++g_lognew >= 8 || strstr(b, "xception") || strstr(b, "FATAL")) { fflush(g_logf); g_lognew = 0; } }
  mutexUnlock(&g_logmx); }

static void *intern(const char *s) { static char *t[1024]; static int n;
  for (int i = 0; i < n; i++) if (!strcmp(t[i], s)) return t[i];
  if (n < 1024) return t[n++] = strdup(s); return strdup(s); }

static void *x_FindClass(void *env, const char *n) { jni_log("JNI FindClass %s", n); return intern(n); }
static void *x_GetMethodID(void *env, void *c, const char *n, const char *s) {
  jmeth_t *m = malloc(sizeof *m); m->cls = c; m->name = strdup(n); m->sig = strdup(s);
  jni_log("JNI GetMethodID %s.%s %s", (char *)c, n, s); return m; }
static void *x_GetFieldID(void *env, void *c, const char *n, const char *s) { return x_GetMethodID(env, c, n, s); }
static void *x_NewStringUTF(void *env, const char *s) { return strdup(s ? s : ""); }
static const char *x_GetStringUTFChars(void *env, void *s, void *iscopy) { if (iscopy) *(uint8_t *)iscopy = 0; return s ? s : ""; }
static void x_ReleaseStringUTFChars(void *env, void *s, const char *c) {}
static int x_GetStringUTFLength(void *env, void *s) { return s ? (int)strlen(s) : 0; }
static int x_GetStringLength(void *env, void *s) { return s ? (int)strlen(s) : 0; }
static void *x_NewGlobalRef(void *env, void *o) { return o; }
static void x_DeleteRef(void *env, void *o) {}
static void *x_GetObjectClass(void *env, void *o) { return intern("java/lang/Object"); }
static int x_zero() { return 0; }
static void *x_null() { return 0; }
static int x_GetVersion(void *env) { return 0x00010006; }
typedef struct { const char *n, *s; void *f; } jnat_t;
static int x_RegisterNatives(void *env, void *c, const jnat_t *m, int n) {
  for (int i = 0; i < n && g_nnat < 512; i++) {
    snprintf(g_nat[g_nnat].cls, 96, "%s", (char *)c); snprintf(g_nat[g_nnat].name, 64, "%s", m[i].n);
    snprintf(g_nat[g_nnat].sig, 128, "%s", m[i].s); g_nat[g_nnat++].fn = m[i].f; }
  jni_log("JNI RegisterNatives %s (%d)", (char *)c, n); return 0; }
static int x_GetJavaVM(void *env, const void **vm) { *vm = &g_vm; return 0; }
static int x_ExceptionCheck(void *env) { return 0; }
static int x_GetArrayLength(void *env, void *a) { return 0; }

/* Call<Type>Method family: log, ask the policy, return the type's default. */
static void * x_CallObject(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallObjectMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  if (m->sig[strlen(m->sig) - 1] == ';' && strstr(m->sig, ")Ljava/lang/String;")) return strdup(jni_policy_string(m->cls ? (char *)m->cls : "", m->name, m->sig));
  { static char dummy[256]; if (strstr(m->sig, ")L") || strstr(m->sig, ")[")) return dummy; }   /* never NULL: e.g. Firebase asserts on getInstance() results */
  return 0;
}
static void * x_CallStaticObject(void *env, void *cls, void *mid, ...) { return (void *)x_CallObject(env, cls, mid); }
/* GetTexturePackPath(i): Java returns one dir per asset pack and null after the last. We keep every texturesN.jpk in one dir -> only i==1 is valid. */
static void *tex_pack(void *env, void *obj, void *mid, int i) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallObjectMethod %s.%s %s (%d)", (char *)m->cls, m->name, m->sig, i);
  return i == 1 ? (void *)strdup(DATA_ROOT "/") : (void *)0; }
static void *x_CallObjectV(void *env, void *obj, void *mid, va_list ap) {
  jmeth_t *m = (jmeth_t *)mid; if (!strcmp(m->name, "GetTexturePackPath")) return tex_pack(env, obj, mid, va_arg(ap, int));
  return x_CallObject(env, obj, mid); }
static void *x_CallObjectA(void *env, void *obj, void *mid, const int *a) {
  jmeth_t *m = (jmeth_t *)mid; if (!strcmp(m->name, "GetTexturePackPath")) return tex_pack(env, obj, mid, a[0]);
  return x_CallObject(env, obj, mid); }
static void *x_CallObjectVar(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; if (!strcmp(m->name, "GetTexturePackPath")) { va_list ap; va_start(ap, mid); int i = va_arg(ap, int); va_end(ap); return tex_pack(env, obj, mid, i); }
  return x_CallObject(env, obj, mid); }
static int x_CallBoolean(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallBooleanMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return (int)jni_policy_int((char *)m->cls, m->name, m->sig, 0);
}
static int x_CallStaticBoolean(void *env, void *cls, void *mid, ...) { return (int)x_CallBoolean(env, cls, mid); }
static int x_CallByte(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallByteMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return (int)jni_policy_int((char *)m->cls, m->name, m->sig, 0);
}
static int x_CallStaticByte(void *env, void *cls, void *mid, ...) { return (int)x_CallByte(env, cls, mid); }
static int x_CallChar(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallCharMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return (int)jni_policy_int((char *)m->cls, m->name, m->sig, 0);
}
static int x_CallStaticChar(void *env, void *cls, void *mid, ...) { return (int)x_CallChar(env, cls, mid); }
static int x_CallShort(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallShortMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return (int)jni_policy_int((char *)m->cls, m->name, m->sig, 0);
}
static int x_CallStaticShort(void *env, void *cls, void *mid, ...) { return (int)x_CallShort(env, cls, mid); }
static int x_CallInt(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallIntMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return (int)jni_policy_int((char *)m->cls, m->name, m->sig, 0);
}
static int x_CallStaticInt(void *env, void *cls, void *mid, ...) { return (int)x_CallInt(env, cls, mid); }
static long long x_CallLong(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallLongMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return (long long)jni_policy_int((char *)m->cls, m->name, m->sig, 0);
}
static long long x_CallStaticLong(void *env, void *cls, void *mid, ...) { return (long long)x_CallLong(env, cls, mid); }
static float x_CallFloat(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallFloatMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return jni_policy_float((char *)m->cls, m->name, m->sig);
}
static float x_CallStaticFloat(void *env, void *cls, void *mid, ...) { return (float)x_CallFloat(env, cls, mid); }
static double x_CallDouble(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallDoubleMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return 0;
}
static double x_CallStaticDouble(void *env, void *cls, void *mid, ...) { return (double)x_CallDouble(env, cls, mid); }
static void x_CallVoid(void *env, void *obj, void *mid, ...) {
  jmeth_t *m = (jmeth_t *)mid; jni_log("JNI CallVoidMethod %s.%s %s", (char *)m->cls, m->name, m->sig);
  return;
}
static void x_CallStaticVoid(void *env, void *cls, void *mid, ...) { x_CallVoid(env, cls, mid); }

static int x_vm_GetEnv(void *vm, void **env, int ver) { *env = &g_env; return 0; }
static int x_vm_Attach(void *vm, void **env, void *args) { *env = &g_env; return 0; }
static int x_vm_Detach(void *vm) { return 0; }

static void init_tabs(void) {
  static int done; if (done) return; done = 1;
  for (int i = 0; i < 235; i++) g_env_tab[i] = (fn)x_zero;           /* unknown slot: returns 0 */
  g_env_tab[4] = (fn)x_GetVersion; g_env_tab[6] = (fn)x_FindClass;
  g_env_tab[15] = (fn)x_null; g_env_tab[21] = (fn)x_NewGlobalRef; g_env_tab[22] = (fn)x_DeleteRef;
  g_env_tab[23] = (fn)x_DeleteRef; g_env_tab[25] = (fn)x_NewGlobalRef; g_env_tab[31] = (fn)x_GetObjectClass;
  g_env_tab[33] = (fn)x_GetMethodID; g_env_tab[94] = (fn)x_GetFieldID;
  g_env_tab[113] = (fn)x_GetMethodID; g_env_tab[144] = (fn)x_GetFieldID;
  g_env_tab[167] = (fn)x_NewStringUTF; g_env_tab[164] = (fn)x_GetStringLength; g_env_tab[168] = (fn)x_GetStringUTFLength;
  g_env_tab[169] = (fn)x_GetStringUTFChars; g_env_tab[170] = (fn)x_ReleaseStringUTFChars;
  g_env_tab[171] = (fn)x_GetArrayLength; g_env_tab[215] = (fn)x_RegisterNatives; g_env_tab[219] = (fn)x_GetJavaVM;
  g_env_tab[228] = (fn)x_ExceptionCheck;
  g_env_tab[34] = (fn)x_CallObjectVar; g_env_tab[114] = (fn)x_CallObjectVar;
  g_env_tab[35] = (fn)x_CallObjectV; g_env_tab[115] = (fn)x_CallObjectV;
  g_env_tab[36] = (fn)x_CallObjectA; g_env_tab[116] = (fn)x_CallObjectA;
  g_env_tab[37] = (fn)x_CallBoolean; g_env_tab[117] = (fn)x_CallStaticBoolean;
  g_env_tab[38] = (fn)x_CallBoolean; g_env_tab[118] = (fn)x_CallStaticBoolean;
  g_env_tab[39] = (fn)x_CallBoolean; g_env_tab[119] = (fn)x_CallStaticBoolean;
  g_env_tab[40] = (fn)x_CallByte; g_env_tab[120] = (fn)x_CallStaticByte;
  g_env_tab[41] = (fn)x_CallByte; g_env_tab[121] = (fn)x_CallStaticByte;
  g_env_tab[42] = (fn)x_CallByte; g_env_tab[122] = (fn)x_CallStaticByte;
  g_env_tab[43] = (fn)x_CallChar; g_env_tab[123] = (fn)x_CallStaticChar;
  g_env_tab[44] = (fn)x_CallChar; g_env_tab[124] = (fn)x_CallStaticChar;
  g_env_tab[45] = (fn)x_CallChar; g_env_tab[125] = (fn)x_CallStaticChar;
  g_env_tab[46] = (fn)x_CallShort; g_env_tab[126] = (fn)x_CallStaticShort;
  g_env_tab[47] = (fn)x_CallShort; g_env_tab[127] = (fn)x_CallStaticShort;
  g_env_tab[48] = (fn)x_CallShort; g_env_tab[128] = (fn)x_CallStaticShort;
  g_env_tab[49] = (fn)x_CallInt; g_env_tab[129] = (fn)x_CallStaticInt;
  g_env_tab[50] = (fn)x_CallInt; g_env_tab[130] = (fn)x_CallStaticInt;
  g_env_tab[51] = (fn)x_CallInt; g_env_tab[131] = (fn)x_CallStaticInt;
  g_env_tab[52] = (fn)x_CallLong; g_env_tab[132] = (fn)x_CallStaticLong;
  g_env_tab[53] = (fn)x_CallLong; g_env_tab[133] = (fn)x_CallStaticLong;
  g_env_tab[54] = (fn)x_CallLong; g_env_tab[134] = (fn)x_CallStaticLong;
  g_env_tab[55] = (fn)x_CallFloat; g_env_tab[135] = (fn)x_CallStaticFloat;
  g_env_tab[56] = (fn)x_CallFloat; g_env_tab[136] = (fn)x_CallStaticFloat;
  g_env_tab[57] = (fn)x_CallFloat; g_env_tab[137] = (fn)x_CallStaticFloat;
  g_env_tab[58] = (fn)x_CallDouble; g_env_tab[138] = (fn)x_CallStaticDouble;
  g_env_tab[59] = (fn)x_CallDouble; g_env_tab[139] = (fn)x_CallStaticDouble;
  g_env_tab[60] = (fn)x_CallDouble; g_env_tab[140] = (fn)x_CallStaticDouble;
  g_env_tab[61] = (fn)x_CallVoid; g_env_tab[141] = (fn)x_CallStaticVoid;
  g_env_tab[62] = (fn)x_CallVoid; g_env_tab[142] = (fn)x_CallStaticVoid;
  g_env_tab[63] = (fn)x_CallVoid; g_env_tab[143] = (fn)x_CallStaticVoid;
  g_vm_tab[4] = (fn)x_vm_Attach; g_vm_tab[5] = (fn)x_vm_Detach; g_vm_tab[6] = (fn)x_vm_GetEnv; g_vm_tab[7] = (fn)x_vm_Attach;
}
void *jni_fake_vm(void) { init_tabs(); return &g_vm; }
void *jni_fake_env(void) { init_tabs(); return &g_env; }
void *jni_native(const char *cls, const char *name) {
  for (int i = 0; i < g_nnat; i++) if (!strcmp(g_nat[i].cls, cls) && !strcmp(g_nat[i].name, name)) return g_nat[i].fn;
  return 0; }
