#pragma once
#include "elf64.h"
int game_run(so_mod *m);
