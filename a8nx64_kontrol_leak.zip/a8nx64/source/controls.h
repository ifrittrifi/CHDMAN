/* controls.h -- configurable gamepad -> engine input layer.
 * Config file: /switch/a8nx64/controls.ini (written with defaults on first run, re-read when the file changes). */
#ifndef CONTROLS_H
#define CONTROLS_H
#include <switch.h>

typedef struct {
  void *env, *cls;
  /* JNIBridge.NativeOnTouch(env, cls, action 0=down 1=up 2=move, x, y, pointer id) -- same entry game.c already used */
  void (*touch)(void *, void *, int, float, float, int);
  /* GL2JNILib.nativeKeyAction / JNIBridge.NativeKeyAction (int, int); argument order is set by key_order in the ini. NULL = unavailable */
  void (*key)(void *, void *, int, int);
  /* GL2JNILib.accelerometerEvent(float, float, float). NULL = unavailable */
  void (*accel)(void *, void *, float, float, float);
} ctl_hooks_t;

void controls_init(const ctl_hooks_t *h);
/* call once per frame; returns 1 when the exit combo is held for the configured time */
int controls_poll(PadState *pad);
#endif
