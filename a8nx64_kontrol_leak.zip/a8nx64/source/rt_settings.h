/* rt_settings.h -- the two switches the MIT-licensed runtime files copied from mc4_nx / android32 look at. */
#ifndef RT_SETTINGS_H
#define RT_SETTINGS_H
#define RT_OPENSLES 1
#endif
