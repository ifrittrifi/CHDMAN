#ifndef IMPORTS_H
#define IMPORTS_H
typedef struct { const char *name; void *addr; } import_t;
extern const import_t g_imports[];       /* sorted by name (generated) */
extern const unsigned g_import_count;
void *imports_lookup(const char *name);  /* bsearch over g_imports */
#endif
