#ifndef JNI_FAKE_H
#define JNI_FAKE_H
#include <stdint.h>
/* A JavaVM/JNIEnv that answers the way a phone with no network, no ads and no Google services would. */
void *jni_fake_vm(void);                         /* JavaVM*  */
void *jni_fake_env(void);                        /* JNIEnv*  */
/* native methods the engine registered with RegisterNatives; NULL if unknown */
void *jni_native(const char *cls, const char *name);
/* Offline policy: values the Java side would return. Edit jni_policy.c to fill in what the log shows. */
int         jni_policy_int(const char *cls, const char *name, const char *sig, int dflt);
void        jni_log_flush(void);
float       jni_policy_float(const char *cls, const char *name, const char *sig);
const char *jni_policy_string(const char *cls, const char *name, const char *sig);
void        jni_log(const char *fmt, ...);
#endif
