#include "imports.h"
#include <string.h>
void *imports_lookup(const char *name) {
  unsigned lo = 0, hi = g_import_count;
  while (lo < hi) { unsigned mid = (lo + hi) / 2; int c = strcmp(name, g_imports[mid].name);
    if (!c) return g_imports[mid].addr;  /* NULL for weak names the toolchain lacks */ if (c < 0) hi = mid; else lo = mid + 1; }
  return 0; }
