/* jni_policy.c -- what Java would answer. Everything not listed gets 0 / false / "" / null and is logged
 * ("JNI call ...") so debug.log shows exactly which calls the engine makes. Keep this file small:
 * only add answers the game really needs. */
#include "jni_fake.h"
#include <string.h>
#include <stdio.h>

/* Data paths are relative to the SD card folder chosen by the launcher. */
#define DATA_ROOT "/switch/a8nx64/data"

int jni_policy_int(const char *cls, const char *name, const char *sig, int dflt) {
  if (!strcmp(name, "isNetworkAvailable") || !strcmp(name, "isConnected") || !strcmp(name, "isOnline")) return 0;
  if (!strcmp(name, "getConnectionType")) return 0;         /* no network: engine stays offline */
  if (!strcmp(name, "GetAPILevel")) return 30;
  if (!strcmp(name, "GetIsNeedDownload")) return 0;
  if (!strcmp(name, "GetIsCompleteCheck")) return 1;      /* the engine polls this until "data check complete" */
  /* Free space: the engine's first checks (data/path selection during init) must still see 0 KB, exactly as in
   * the run that reached the menu: any larger value there switches it to the models*.jpk/textures*.jpk
   * install path and the screen stays black. Only later calls (menu stage: "not enough free space" +
   * ExitApplication) get the real answer. FREE_AFTER = number of initial calls that still return 0; override
   * with the first integer in /switch/a8nx64/freespace_after.txt (999999 = always 0). */
  if (!strcmp(name, "GetFreeSpaceInKBytes") || !strcmp(name, "GetFreeSpaceSDInKBytes")) {
    static int after = -1; static volatile int calls;
    if (after < 0) {
      after = 5;
      FILE *f = fopen("/switch/a8nx64/freespace_after.txt", "r");
      if (f) { int v; if (fscanf(f, "%d", &v) == 1 && v >= 0) after = v; fclose(f); }
    }
    int n = __atomic_add_fetch(&calls, 1, __ATOMIC_RELAXED);
    return n > after ? 16 * 1024 * 1024 : 0;   /* 16 GB */
  }
  return dflt;
}
float jni_policy_float(const char *cls, const char *name, const char *sig) { return 0.0f; }
const char *jni_policy_string(const char *cls, const char *name, const char *sig) {
  if (!strcmp(name, "getAbsolutePath") || !strcmp(name, "getFilesDir") || !strcmp(name, "getDataDir")) return DATA_ROOT;
  if (!strcmp(name, "getPackageName")) return "com.gameloft.android.ANMP.GloftA8HM";
  if (!strcmp(name, "getLanguage")) return "en";
  if (!strcmp(name, "getCountry")) return "US";
  if (strstr(name, "PackPath")) return DATA_ROOT "/";
  if (!strncmp(name, "Retrieve", 8)) return !strcmp(name, "RetrieveNativeLibraryPath") ? "/switch/a8nx64/lib" : DATA_ROOT;
  if (!strcmp(name, "GetDeviceManufacturer")) return "Nintendo";
  if (!strcmp(name, "GetDeviceModel") || !strcmp(name, "GetPhoneProduct") || !strcmp(name, "GetPhoneDevice")) return "Switch";
  if (!strcmp(name, "GetCPUAbi")) return "arm64-v8a";
  if (!strcmp(name, "GetFirmware")) return "11";
  if (!strcmp(name, "GetApkPath") || !strcmp(name, "GetApkPathsSingleString")) return "/switch/a8nx64/apk/base.apk";
  if (!strcmp(name, "GetGameName")) return "Asphalt 8";
  if (!strcmp(name, "GetAndroidID") || !strcmp(name, "GetSerial") || !strcmp(name, "GetCPUSerial")) return "0000000000000001";
  return "";
}
