/* controls.c -- gamepad mapping with a text config.  UNTESTED on hardware.
 *
 * Why a file: the engine ships its own controller schemes (scheme_controller_specific.bgin, controllers_menu.bgin are opened
 * in debug.log), but the loader never delivered any pad event to it. This layer turns Switch buttons into the same inputs
 * an Android pad / touch screen would produce, and every binding can be changed without recompiling.
 *
 * ini format (';' or '#' start a comment):
 *   [general]  mode = keys|touch|both    key_order = action_code|code_action   stick_deadzone = 0.25
 *              stick_dpad = 1            accel = 0   accel_gain = 9.81         exit = MINUS+PLUS   exit_ms = 600
 *              screen_w = 1280           screen_h = 720                        log_events = 40
 *   [keys]     <SWITCH BUTTON> = <Android keycode>          e.g.  A = 96
 *   [touch]    <SWITCH BUTTON> = <x>,<y>                    e.g.  ZR = 1180,560    (screen pixels, 1280x720)
 * Switch buttons: A B X Y L R ZL ZR PLUS MINUS UP DOWN LEFT RIGHT STICK_L STICK_R */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <ctype.h>
#include <sys/stat.h>
#include "controls.h"
#include "jni_fake.h"

#define INI "/switch/a8nx64/controls.ini"
#define NBTN 16
static const struct { const char *name; u64 mask; int key; int tx, ty; } B0[NBTN] = {
  /* defaults: Android gamepad keycodes. Touch coordinates are placeholders for a 1280x720 screen: calibrate in the ini. */
  {"A", HidNpadButton_A, 96, 1180, 560}, {"B", HidNpadButton_B, 97, 1090, 640}, {"X", HidNpadButton_X, 99, 1180, 440},
  {"Y", HidNpadButton_Y, 100, 1090, 360}, {"L", HidNpadButton_L, 102, 120, 640}, {"R", HidNpadButton_R, 103, 1160, 640},
  {"ZL", HidNpadButton_ZL, 104, 120, 560}, {"ZR", HidNpadButton_ZR, 105, 1180, 560}, {"PLUS", HidNpadButton_Plus, 108, 640, 40},
  {"MINUS", HidNpadButton_Minus, 109, 560, 40}, {"UP", HidNpadButton_Up, 19, 640, 200}, {"DOWN", HidNpadButton_Down, 20, 640, 520},
  {"LEFT", HidNpadButton_Left, 21, 320, 360}, {"RIGHT", HidNpadButton_Right, 22, 960, 360},
  {"STICK_L", HidNpadButton_StickL, 106, 0, 0}, {"STICK_R", HidNpadButton_StickR, 107, 0, 0} };

enum { M_KEYS = 1, M_TOUCH = 2 };
static struct {
  int mode, order_code_first, stick_dpad, accel, exit_ms, sw, sh, log_events;
  float dz, gain; u64 exit_mask;
  int key[NBTN], tx[NBTN], ty[NBTN];
} C;
static ctl_hooks_t H; static u64 g_prev; static int g_sk_l, g_sk_r, g_exit_t, g_nlog, g_inited; static time_t g_mtime;

static void defaults(void) {
  memset(&C, 0, sizeof C); C.mode = M_KEYS; C.dz = 0.25f; C.stick_dpad = 1; C.gain = 9.81f; C.exit_ms = 600; C.sw = 1280; C.sh = 720; C.log_events = 40;
  C.exit_mask = HidNpadButton_Minus | HidNpadButton_Plus;
  for (int i = 0; i < NBTN; i++) { C.key[i] = B0[i].key; C.tx[i] = B0[i].tx; C.ty[i] = B0[i].ty; } }

static int btn_index(const char *n) { for (int i = 0; i < NBTN; i++) if (!strcasecmp(n, B0[i].name)) return i; return -1; }
static u64 parse_combo(char *v) {
  u64 m = 0; for (char *t = strtok(v, "+ "); t; t = strtok(NULL, "+ ")) { int i = btn_index(t); if (i >= 0) m |= B0[i].mask; } return m; }
static char *trim(char *s) { while (isspace((unsigned char)*s)) s++; char *e = s + strlen(s); while (e > s && isspace((unsigned char)e[-1])) *--e = 0; return s; }

static void write_default(void) {
  FILE *f = fopen(INI, "w"); if (!f) return;
  fputs("; a8nx64 controls. Edit and save: the file is re-read while the game runs.\n"
        "[general]\nmode = keys            ; keys = Android gamepad keycodes | touch = fake finger taps | both\n"
        "key_order = action_code   ; order of the 2 ints of nativeKeyAction: action_code or code_action (if buttons do nothing, flip it)\n"
        "stick_deadzone = 0.25\nstick_dpad = 1          ; left stick left/right is sent as DPAD_LEFT/DPAD_RIGHT (steering)\n"
        "accel = 0               ; 1 = left stick X is also sent as tilt (accelerometerEvent)\naccel_gain = 9.81\n"
        "exit = MINUS+PLUS       ; hold to quit (PLUS alone is START for the game)\nexit_ms = 600\nscreen_w = 1280\nscreen_h = 720\nlog_events = 40       ; first N sent events are written to debug.log\n\n"
        "[keys]                  ; Android keycodes: A=96 B=97 X=99 Y=100 L1=102 R1=103 L2=104 R2=105 START=108 SELECT=109 DPAD U/D/L/R=19/20/21/22\n", f);
  for (int i = 0; i < NBTN; i++) fprintf(f, "%s = %d\n", B0[i].name, B0[i].key);
  fputs("\n[touch]                 ; used when mode = touch or both; x,y in screen pixels\n", f);
  for (int i = 0; i < NBTN; i++) if (B0[i].tx) fprintf(f, "%s = %d,%d\n", B0[i].name, B0[i].tx, B0[i].ty);
  fclose(f); }

static void load(void) {
  defaults(); struct stat st; if (stat(INI, &st) != 0) { write_default(); stat(INI, &st); }
  g_mtime = st.st_mtime; FILE *f = fopen(INI, "r"); if (!f) { jni_log("[ctl] cannot read " INI ", using defaults"); return; }
  char line[200], sec[16] = ""; int bad = 0;
  while (fgets(line, sizeof line, f)) {
    char *c = strpbrk(line, ";#"); if (c) *c = 0; char *s = trim(line); if (!*s) continue;
    if (*s == '[') { snprintf(sec, sizeof sec, "%.*s", (int)strcspn(s + 1, "]"), s + 1); continue; }
    char *eq = strchr(s, '='); if (!eq) { bad++; continue; } *eq = 0; char *k = trim(s), *v = trim(eq + 1);
    if (!strcasecmp(sec, "general")) {
      if (!strcasecmp(k, "mode")) C.mode = !strcasecmp(v, "touch") ? M_TOUCH : !strcasecmp(v, "both") ? M_KEYS | M_TOUCH : M_KEYS;
      else if (!strcasecmp(k, "key_order")) C.order_code_first = !strcasecmp(v, "code_action");
      else if (!strcasecmp(k, "stick_deadzone")) C.dz = (float)atof(v);
      else if (!strcasecmp(k, "stick_dpad")) C.stick_dpad = atoi(v);
      else if (!strcasecmp(k, "accel")) C.accel = atoi(v);
      else if (!strcasecmp(k, "accel_gain")) C.gain = (float)atof(v);
      else if (!strcasecmp(k, "exit")) C.exit_mask = parse_combo(v);
      else if (!strcasecmp(k, "exit_ms")) C.exit_ms = atoi(v);
      else if (!strcasecmp(k, "screen_w")) C.sw = atoi(v);
      else if (!strcasecmp(k, "screen_h")) C.sh = atoi(v);
      else if (!strcasecmp(k, "log_events")) C.log_events = atoi(v);
      else bad++;
    } else if (!strcasecmp(sec, "keys") || !strcasecmp(sec, "touch")) {
      int i = btn_index(k); if (i < 0) { bad++; continue; }
      if (sec[0] == 'k' || sec[0] == 'K') C.key[i] = atoi(v); else sscanf(v, "%d , %d", &C.tx[i], &C.ty[i]);
    } else bad++; }
  fclose(f); if (C.dz < 0.f) C.dz = 0.f; if (C.dz > 0.9f) C.dz = 0.9f; if (C.sw < 1) C.sw = 1280; if (C.sh < 1) C.sh = 720;
  jni_log("[ctl] loaded " INI ": mode=%d key_order=%s dz=%.2f stick_dpad=%d accel=%d exit_mask=0x%llx (%d ignored lines)", C.mode,
          C.order_code_first ? "code_action" : "action_code", C.dz, C.stick_dpad, C.accel, (unsigned long long)C.exit_mask, bad); }

void controls_init(const ctl_hooks_t *h) { H = *h; load(); g_inited = 1;
  jni_log("[ctl] hooks: touch=%s key=%s accel=%s", H.touch ? "yes" : "NO", H.key ? "yes" : "NO", H.accel ? "yes" : "NO"); }

static void send_key(int code, int down) {
  if (!H.key) return;
  int action = down ? 0 : 1;   /* Android ACTION_DOWN 0 / ACTION_UP 1 */
  if (g_nlog < C.log_events) { g_nlog++; jni_log("[ctl] key code=%d %s", code, down ? "down" : "up"); }
  if (C.order_code_first) H.key(H.env, H.cls, code, action); else H.key(H.env, H.cls, action, code); }
static void send_touch(int id, int act, int x, int y) {
  if (!H.touch) return;
  if (g_nlog < C.log_events) { g_nlog++; jni_log("[ctl] touch id=%d act=%d x=%d y=%d", id, act, x, y); }
  H.touch(H.env, H.cls, act, (float)x, (float)y, id); }

int controls_poll(PadState *pad) {
  if (!g_inited) return 0;
  struct stat st; static unsigned n; if ((++n % 120) == 0 && stat(INI, &st) == 0 && st.st_mtime != g_mtime) load();   /* hot reload */
  u64 now = padGetButtons(pad);
  if (C.exit_mask && (now & C.exit_mask) == C.exit_mask) { g_exit_t += 16; if (g_exit_t >= C.exit_ms) { jni_log("[ctl] exit combo held"); return 1; } return 0; }
  g_exit_t = 0;
  for (int i = 0; i < NBTN; i++) {
    int d = (now & B0[i].mask) != 0, was = (g_prev & B0[i].mask) != 0; if (d == was) continue;
    if ((C.mode & M_KEYS) && C.key[i] > 0) send_key(C.key[i], d);
    if ((C.mode & M_TOUCH) && C.tx[i] > 0) send_touch(32 + i, d ? 0 : 1, C.tx[i], C.ty[i]); }
  g_prev = now;
  HidAnalogStickState ls = padGetStickPos(pad, 0);
  float sx = ls.x / 32767.f; if (sx > 1.f) sx = 1.f; if (sx < -1.f) sx = -1.f;
  if (C.stick_dpad) {
    int l = sx < -C.dz, r = sx > C.dz;
    if (l != g_sk_l) send_key(21, l);
    if (r != g_sk_r) send_key(22, r);
    g_sk_l = l; g_sk_r = r; }
  if (C.accel && H.accel) { float a = (sx > -C.dz && sx < C.dz) ? 0.f : sx; H.accel(H.env, H.cls, -a * C.gain, 0.f, 9.81f); }
  return 0; }
