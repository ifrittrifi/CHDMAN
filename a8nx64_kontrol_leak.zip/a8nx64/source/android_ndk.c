/* android_ndk.c -- NDK entry points the game imports: assets, window, looper, sensors.
 * Assets are read from <ROOT>/assets/ (the APK's assets/ folder, extracted on the SD card). Written for
 * AArch64 (off_t is 64-bit here); the structure follows mc4_nx's mc4_asset.c / runtime android_ndk.c (MIT). */
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <switch.h>
#include "util.h"

#define ASSET_ROOT "/switch/a8nx64/assets/"

typedef struct { FILE *f; long size; void *buf; } Asset;
typedef struct { DIR *d; char name[256]; } AssetDir;

static char g_mgr;                                       /* the "manager": any non-NULL pointer works */
void *b_AAssetManager_fromJava(void *env, void *am) { return &g_mgr; }

void *b_AAssetManager_open(void *mgr, const char *filename, int mode) {
  char path[600]; while (filename && *filename == '/') filename++;
  snprintf(path, sizeof path, ASSET_ROOT "%s", filename ? filename : "");
  FILE *f = fopen(path, "rb");
  if (!f) { static int n; if (n++ < 40) debugPrintf("[asset] %s: not found", filename ? filename : "(null)"); return NULL; }
  Asset *a = calloc(1, sizeof *a); if (!a) { fclose(f); return NULL; }
  a->f = f; fseek(f, 0, SEEK_END); a->size = ftell(f); fseek(f, 0, SEEK_SET); return a; }
int b_AAsset_read(void *asset, void *buf, size_t count) {
  Asset *a = asset; return a && a->f ? (int)fread(buf, 1, count, a->f) : -1; }
int64_t b_AAsset_seek(void *asset, int64_t off, int whence) {          /* off_t is 64-bit on bionic arm64 */
  Asset *a = asset; if (!a || !a->f || fseek(a->f, (long)off, whence)) return -1; return ftell(a->f); }
int64_t b_AAsset_seek64(void *asset, int64_t off, int whence) { return b_AAsset_seek(asset, off, whence); }
int64_t b_AAsset_getLength(void *asset) { Asset *a = asset; return a ? a->size : 0; }
int64_t b_AAsset_getLength64(void *asset) { return b_AAsset_getLength(asset); }
int64_t b_AAsset_getRemainingLength(void *asset) { Asset *a = asset; return a && a->f ? a->size - ftell(a->f) : 0; }
int64_t b_AAsset_getRemainingLength64(void *asset) { return b_AAsset_getRemainingLength(asset); }
const void *b_AAsset_getBuffer(void *asset) {                          /* whole file in memory, kept until close */
  Asset *a = asset; if (!a) return NULL; if (a->buf) return a->buf;
  a->buf = malloc(a->size ? a->size : 1); if (!a->buf) return NULL;
  long pos = ftell(a->f); fseek(a->f, 0, SEEK_SET);
  if ((long)fread(a->buf, 1, a->size, a->f) != a->size) { free(a->buf); a->buf = NULL; return NULL; }
  fseek(a->f, pos, SEEK_SET); return a->buf; }
int b_AAsset_isAllocated(void *asset) { return 0; }
void b_AAsset_close(void *asset) { Asset *a = asset; if (!a) return; if (a->f) fclose(a->f); free(a->buf); free(a); }
void *b_AAssetManager_openDir(void *mgr, const char *dirname) {
  char path[600]; while (dirname && *dirname == '/') dirname++;
  snprintf(path, sizeof path, ASSET_ROOT "%s", dirname ? dirname : "");
  DIR *d = opendir(path); if (!d) return NULL;
  AssetDir *r = calloc(1, sizeof *r); if (!r) { closedir(d); return NULL; } r->d = d; return r; }
const char *b_AAssetDir_getNextFileName(void *dir) {
  AssetDir *r = dir; struct dirent *e;
  while (r && (e = readdir(r->d))) { if (e->d_name[0] == '.') continue; snprintf(r->name, sizeof r->name, "%s", e->d_name); return r->name; }
  return NULL; }
void b_AAssetDir_close(void *dir) { AssetDir *r = dir; if (!r) return; if (r->d) closedir(r->d); free(r); }

/* ---- window: a fixed-size surface; main.c owns the real EGL window ---- */
int g_win_w = 1280, g_win_h = 720;
void *b_ANativeWindow_fromSurface(void *env, void *surface) { return nwindowGetDefault(); }
void b_ANativeWindow_acquire(void *w) {}
void b_ANativeWindow_release(void *w) {}
int32_t b_ANativeWindow_getWidth(void *w) { return g_win_w; }
int32_t b_ANativeWindow_getHeight(void *w) { return g_win_h; }
int32_t b_ANativeWindow_setBuffersGeometry(void *w, int32_t width, int32_t height, int32_t fmt) { return 0; }

/* ---- looper and sensors: present, empty (no sensors on this device) ---- */
static char g_looper, g_sensor_mgr, g_queue;
void *b_ALooper_forThread(void) { return &g_looper; }
void *b_ALooper_prepare(int opts) { return &g_looper; }
void b_ALooper_acquire(void *l) {}
void b_ALooper_release(void *l) {}
void b_ALooper_wake(void *l) {}
void *b_ASensorManager_getInstance(void) { return &g_sensor_mgr; }
const void *b_ASensorManager_getDefaultSensor(void *m, int type) { return NULL; }
void *b_ASensorManager_createEventQueue(void *m, void *looper, int ident, void *cb, void *data) { return &g_queue; }
int b_ASensorManager_destroyEventQueue(void *m, void *q) { return 0; }
int b_ASensorEventQueue_enableSensor(void *q, const void *s) { return -1; }
int b_ASensorEventQueue_disableSensor(void *q, const void *s) { return 0; }
int b_ASensorEventQueue_setEventRate(void *q, const void *s, int32_t us) { return 0; }
int b_ASensorEventQueue_hasEvents(void *q) { return 0; }
int b_ASensorEventQueue_getEvents(void *q, void *ev, size_t n) { return 0; }
