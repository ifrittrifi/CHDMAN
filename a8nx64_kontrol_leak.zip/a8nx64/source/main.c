/* main.c -- launcher glue for the AArch64 build (devkitA64 + libnx). UNTESTED: the first hardware run
 * is expected to stop somewhere in here or in the engine; debug.log says where. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <switch.h>
#include "elf64.h"
#include "imports.h"
#include "jni_fake.h"
#include "game.h"
extern void *memalign(size_t, size_t);
extern void bionic_tls_setup(void);
extern void shim_set_module(uintptr_t base, uint64_t phoff, unsigned phnum);

#define ROOT "/switch/a8nx64"
#define ENGINE ROOT "/lib/libAsphalt8.so"

/* Memory for the image. The bytes are written through `src` (ordinary heap) and relocated for the address
 * they will have at `dst` in the process' code region. Only afterwards is src mapped there with
 * svcMapProcessCodeMemory (src becomes inaccessible), and the executable pages are switched to R+X while
 * data and .bss stay R+W. (libnx's Jit helper makes the whole range R+X, which faulted on .bss.) */
typedef struct { void *src; void *dst; size_t size; } img_t;
/* Own search for a free range in the ASLR region (libnx's virtmemFind* returned NULL here). Walks the
 * address space with svcQueryMemory and takes the first unmapped hole big enough, with 4 KiB guards. */
static void *find_free(size_t size) {
  u64 base = 0, asz = 0;
  svcGetInfo(&base, InfoType_AslrRegionAddress, CUR_PROCESS_HANDLE, 0);
  svcGetInfo(&asz, InfoType_AslrRegionSize, CUR_PROCESS_HANDLE, 0);
  jni_log("ASLR region 0x%llx size 0x%llx", (unsigned long long)base, (unsigned long long)asz);
  u64 want = (u64)size + 0x2000, a = base + 0x10000000ull;       /* start well above the low mappings */
  if (a >= base + asz) a = base;
  while (a < base + asz) {
    MemoryInfo mi; u32 pi;
    if (R_FAILED(svcQueryMemory(&mi, &pi, a))) break;
    u64 e = mi.addr + mi.size;
    if (mi.type == MemType_Unmapped) {
      u64 s = mi.addr < a ? a : mi.addr, lim = e < base + asz ? e : base + asz;
      if (lim > s && lim - s >= want) return (void *)((s + 0x1000 + 0xfff) & ~0xfffull); }
    if (e <= a) break;
    a = e; }
  return NULL; }

static int alloc_code(size_t size, void **rw, uintptr_t *rx, void *ud) {
  img_t *im = ud; im->size = size;
  u64 total = 0, used = 0;
  svcGetInfo(&total, InfoType_TotalMemorySize, CUR_PROCESS_HANDLE, 0);
  svcGetInfo(&used, InfoType_UsedMemorySize, CUR_PROCESS_HANDLE, 0);
  jni_log("alloc_code size=0x%zx  process memory total=0x%llx used=0x%llx", size, (unsigned long long)total, (unsigned long long)used);
  im->src = memalign(0x1000, size);
  jni_log("memalign -> %p", im->src);
  if (!im->src) {                                   /* fall back: plain malloc, aligned by hand */
    void *raw = malloc(size + 0x1000); jni_log("malloc(size+0x1000) -> %p", raw);
    if (!raw) return -1;
    im->src = (void *)(((uintptr_t)raw + 0xfff) & ~(uintptr_t)0xfff); }
  memset(im->src, 0, size);
  im->dst = virtmemFindCodeMemory(size, 0x1000);
  jni_log("virtmemFindCodeMemory -> %p", im->dst);
  if (!im->dst) { im->dst = find_free(size); jni_log("find_free -> %p", im->dst); }
  if (!im->dst) return -2;
  *rw = im->src; *rx = (uintptr_t)im->dst; return 0; }
static Result set_perm(Handle self, img_t *im, size_t off, size_t len, u32 perm, const char *what) {
  if (!len) return 0;
  Result rc = svcSetProcessMemoryPermission(self, (u64)im->dst + off, len, perm);
  jni_log("%s 0x%zx..0x%zx rc=0x%x", what, off, off + len, rc); return rc; }
static Result map_image(img_t *im, const so_mod *m) {
  Handle self = envGetOwnProcessHandle();
  Result rc = svcMapProcessCodeMemory(self, (u64)im->dst, (u64)im->src, im->size);
  jni_log("svcMapProcessCodeMemory dst=%p src=%p size=0x%zx rc=0x%x", im->dst, im->src, im->size, rc);
  if (R_FAILED(rc)) return rc;
  /* the mapping starts with NO access: give every range its permission explicitly */
  size_t xs = m->x_start, xe = m->x_end, total = im->size;
  if (R_FAILED(rc = set_perm(self, im, 0, xs, Perm_Rw, "RW (before code)"))) return rc;
  if (R_FAILED(rc = set_perm(self, im, xs, xe - xs, Perm_Rx, "RX (code)"))) return rc;
  return set_perm(self, im, xe, total - xe, Perm_Rw, "RW (data, bss)"); }
static void *resolve(const char *n, void *ud) { return imports_lookup(n); }
static void unresolved(const char *n, void *ud) { jni_log("UNRESOLVED %s", n); }
static void trap(void) { jni_log("call through an unresolved import"); abort(); }

#include <malloc.h>
int main(void) {
  mallopt(M_TRIM_THRESHOLD, 1 << 30); mallopt(M_TOP_PAD, 64 << 20);   /* never give heap pages back: late/stale accesses must not fault */
  consoleInit(NULL);
  FILE *f = fopen(ENGINE, "rb");
  if (!f) { printf("missing %s\n", ENGINE); consoleUpdate(NULL); svcSleepThread(3000000000ll); consoleExit(NULL); return 1; }
  fseek(f, 0, SEEK_END); long len = ftell(f); rewind(f);
  void *buf = malloc(len); fread(buf, 1, len, f); fclose(f);

  static img_t img; so_mod m;
  int r = so_load(&m, buf, len, alloc_code, &img);               jni_log("so_load=%d", r);
  if (!r) r = so_relocate(&m, resolve, unresolved, (void *)trap, NULL);
  jni_log("so_relocate=%d relocs=%zu unresolved=%zu", r, m.n_reloc, m.n_unresolved);
  if (r) { printf("load failed (%d), see debug.log\n", r); consoleUpdate(NULL); svcSleepThread(4000000000ll); consoleExit(NULL); return 1; }
  free(buf);
  Result mr = map_image(&img, &m); if (R_FAILED(mr)) { jni_log("map failed"); printf("map failed 0x%x\n", mr); consoleUpdate(NULL); svcSleepThread(4000000000ll); consoleExit(NULL); return 1; }
  shim_set_module(m.rx, m.phoff, m.phnum);                       /* dl_iterate_phdr: lets the game's unwinder find .eh_frame */
  bionic_tls_setup();                                            /* TPIDR_EL0 block: the game reads its stack canary there */
  so_rebase(&m);                                                 /* the rw copy is gone: use the mapped image */
  /* run the constructors one by one and log each, so a crash shows exactly which one */
  jni_log("running DT_INIT %p and %zu init_array entries", (void *)m.init_fn, m.n_init);
  if (m.init_fn) { jni_log("INIT fn +0x%lx", (unsigned long)(m.init_fn - m.rx)); ((void (*)(void))m.init_fn)(); }
  for (size_t i = 0; i < m.n_init; i++) {
    uintptr_t fn = m.init_array[i]; if (!fn || fn == (uintptr_t)-1) continue;
    jni_log("init[%zu] +0x%lx", i, (unsigned long)(fn - m.rx));
    ((void (*)(void))fn)(); }
  jni_log("constructors done");

  int (*on_load)(void *, void *) = so_sym(&m, "JNI_OnLoad");
  if (on_load) jni_log("JNI_OnLoad -> 0x%x", on_load(jni_fake_vm(), NULL));
  consoleExit(NULL);
  int gr = game_run(&m);
  return gr; }
