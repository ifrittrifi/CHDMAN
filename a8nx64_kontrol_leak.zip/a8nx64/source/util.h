/* util.h -- the few helpers the copied runtime files use, mapped onto this port's log. */
#ifndef DCR_UTIL_H
#define DCR_UTIL_H
#include <stdint.h>
#include <stddef.h>
extern void jni_log(const char *fmt, ...);
#define debugPrintf(...) jni_log(__VA_ARGS__)
#define ALIGN_MEM(x, a) (((x) + ((a) - 1)) & ~((uintptr_t)(a) - 1))
#define ARRAY_SIZE(x)   ((int)(sizeof(x) / sizeof((x)[0])))
#endif
