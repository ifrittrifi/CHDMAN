#include "elf64.h"
#include <string.h>

typedef struct { uint8_t id[16]; uint16_t type, machine; uint32_t version; uint64_t entry, phoff, shoff;
                 uint32_t flags; uint16_t ehsize, phentsize, phnum, shentsize, shnum, shstrndx; } Ehdr;
typedef struct { uint32_t type, flags; uint64_t off, vaddr, paddr, filesz, memsz, align; } Phdr;
typedef struct { int64_t tag; uint64_t val; } Dyn;
typedef struct { uint32_t name; uint8_t info, other; uint16_t shndx; uint64_t value, size; } Sym;
typedef struct { uint64_t off, info; int64_t addend; } Rela;

enum { PT_LOAD = 1, PT_DYNAMIC = 2 };
enum { DT_NULL, DT_NEEDED, DT_PLTRELSZ, DT_PLTGOT, DT_HASH, DT_STRTAB, DT_SYMTAB, DT_RELA, DT_RELASZ,
       DT_RELAENT, DT_STRSZ, DT_SYMENT, DT_INIT, DT_FINI, DT_SONAME, DT_RPATH, DT_SYMBOLIC, DT_REL,
       DT_RELSZ, DT_RELENT, DT_PLTREL, DT_DEBUG, DT_TEXTREL, DT_JMPREL, DT_BIND_NOW, DT_INIT_ARRAY,
       DT_FINI_ARRAY, DT_INIT_ARRAYSZ, DT_FINI_ARRAYSZ };
#define DT_GNU_HASH 0x6ffffef5
enum { R_NONE = 0, R_ABS64 = 257, R_GLOB_DAT = 1025, R_JUMP_SLOT = 1026, R_RELATIVE = 1027 };

/* dynamic values kept between so_load and so_relocate */
static struct { uint64_t rela, relasz, jmprel, pltrelsz, gnuhash, hash; } g_dyn;

int so_load(so_mod *m, const void *file, size_t len, so_alloc_fn alloc, void *ud) {
  const uint8_t *f = file; const Ehdr *eh = file;
  memset(m, 0, sizeof *m);
  if (len < sizeof(Ehdr) || memcmp(eh->id, "\x7f" "ELF", 4) || eh->id[4] != 2 || eh->machine != 183 || eh->type != 3)
    return -1;                                   /* not an ELF64 AArch64 ET_DYN */
  if (eh->phoff + (uint64_t)eh->phnum * sizeof(Phdr) > len) return -2;
  const Phdr *ph = (const Phdr *)(f + eh->phoff);
  uint64_t top = 0; const Phdr *dynph = NULL;
  for (int i = 0; i < eh->phnum; i++) {
    if (ph[i].type == PT_LOAD) { if (ph[i].off + ph[i].filesz > len) return -3;
                                 if (ph[i].vaddr + ph[i].memsz > top) top = ph[i].vaddr + ph[i].memsz; }
    else if (ph[i].type == PT_DYNAMIC) dynph = &ph[i];
  }
  if (!top || !dynph) return -4;
  m->size = (size_t)((top + 0xfff) & ~0xfffull); m->phoff = eh->phoff; m->phnum = eh->phnum;
  void *rw; uintptr_t rx;
  if (alloc(m->size, &rw, &rx, ud)) return -5;
  m->rw = rw; m->rx = rx;
  m->x_start = (size_t)-1; m->x_end = 0;
  for (int i = 0; i < eh->phnum; i++) if (ph[i].type == PT_LOAD) {
    memcpy(m->rw + ph[i].vaddr, f + ph[i].off, ph[i].filesz);
    if (ph[i].flags & 1) {                                   /* PF_X: becomes read-execute; everything else stays read-write */
      size_t a = (size_t)(ph[i].vaddr & ~0xfffull), b = (size_t)((ph[i].vaddr + ph[i].memsz + 0xfff) & ~0xfffull);
      if (a < m->x_start) m->x_start = a; if (b > m->x_end) m->x_end = b; } }

  memset(&g_dyn, 0, sizeof g_dyn);
  const Dyn *d = (const Dyn *)(m->rw + dynph->vaddr);
  uint64_t strtab = 0, symtab = 0, ia = 0, ias = 0;
  for (; d->tag != DT_NULL; d++) switch (d->tag) {
    case DT_STRTAB: strtab = d->val; break;      case DT_SYMTAB: symtab = d->val; break;
    case DT_RELA: g_dyn.rela = d->val; break;    case DT_RELASZ: g_dyn.relasz = d->val; break;
    case DT_JMPREL: g_dyn.jmprel = d->val; break; case DT_PLTRELSZ: g_dyn.pltrelsz = d->val; break;
    case DT_INIT: m->init_fn = d->val ? m->rx + d->val : 0; break;
    case DT_INIT_ARRAY: ia = d->val; break;      case DT_INIT_ARRAYSZ: ias = d->val; break;
    case DT_GNU_HASH: g_dyn.gnuhash = d->val; break; case DT_HASH: g_dyn.hash = d->val; break;
    default: break; }
  if (!strtab || !symtab) return -6;
  m->strtab = (const char *)(m->rw + strtab); m->symtab = m->rw + symtab;
  if (ia) { m->init_array = (uintptr_t *)(m->rw + ia); m->n_init = ias / 8; }

  /* symbol count: DT_HASH nchain, else walk the DT_GNU_HASH chains */
  if (g_dyn.hash) m->nsyms = ((const uint32_t *)(m->rw + g_dyn.hash))[1];
  else if (g_dyn.gnuhash) {
    const uint32_t *h = (const uint32_t *)(m->rw + g_dyn.gnuhash);
    uint32_t nb = h[0], so = h[1], bl = h[2];
    const uint32_t *bk = (const uint32_t *)((const uint8_t *)(h + 4) + (size_t)bl * 8);
    const uint32_t *ch = bk + nb; uint32_t mx = 0;
    for (uint32_t i = 0; i < nb; i++) if (bk[i] > mx) mx = bk[i];
    if (mx < so) m->nsyms = so;
    else { while (!(ch[mx - so] & 1)) mx++; m->nsyms = mx + 1; }
  } else return -7;
  return 0;
}

int so_relocate(so_mod *m, so_resolve_fn res, so_unresolved_fn unres, void *stub, void *ud) {
  const Sym *syms = (const Sym *)m->symtab;
  const uint64_t ranges[2][2] = { { g_dyn.rela, g_dyn.relasz }, { g_dyn.jmprel, g_dyn.pltrelsz } };
  for (int r = 0; r < 2; r++) {
    if (!ranges[r][0]) continue;
    const Rela *rl = (const Rela *)(m->rw + ranges[r][0]);
    size_t n = ranges[r][1] / sizeof(Rela);
    for (size_t i = 0; i < n; i++, m->n_reloc++) {
      uint32_t type = (uint32_t)rl[i].info, si = (uint32_t)(rl[i].info >> 32);
      uint64_t *where = (uint64_t *)(m->rw + rl[i].off);
      if (type == R_NONE) continue;
      if (type == R_RELATIVE) { *where = m->rx + rl[i].addend; continue; }
      if (type != R_ABS64 && type != R_GLOB_DAT && type != R_JUMP_SLOT) return -(int)type;
      uint64_t val;
      if (si >= m->nsyms) return -1;
      const Sym *s = &syms[si];
      if (s->shndx) val = m->rx + s->value;                     /* defined in this module */
      else {
        const char *name = m->strtab + s->name; void *p = res(name, ud);
        if (!p) { if ((s->info >> 4) == 2) val = 0;              /* STB_WEAK */
                  else { m->n_unresolved++; if (unres) unres(name, ud); p = stub; val = (uint64_t)(uintptr_t)p; } }
        else val = (uint64_t)(uintptr_t)p;
      }
      *where = (type == R_GLOB_DAT || type == R_JUMP_SLOT) ? val : val + rl[i].addend;
    }
  }
  return 0;
}

void *so_sym(const so_mod *m, const char *name) {
  const Sym *syms = (const Sym *)m->symtab;
  for (size_t i = 1; i < m->nsyms; i++)
    if (syms[i].shndx && !strcmp(m->strtab + syms[i].name, name)) return (void *)(m->rx + syms[i].value);
  return NULL;
}

void so_run_init(so_mod *m) {
  if (m->init_fn) ((void (*)(void))m->init_fn)();
  for (size_t i = 0; i < m->n_init; i++) {
    uintptr_t fn = m->init_array[i];                 /* already relocated (RELATIVE) */
    if (fn && fn != (uintptr_t)-1) ((void (*)(void))fn)();
  }
}

void so_rebase(so_mod *m) {
  ptrdiff_t d = (ptrdiff_t)((uint8_t *)m->rx - m->rw);
  m->symtab += d; m->strtab += d;
  if (m->init_array) m->init_array = (uintptr_t *)((uint8_t *)m->init_array + d);
  m->rw = (uint8_t *)m->rx; }
