/* elf64.h -- minimal AArch64 ELF shared-object loader (no libc ELF headers needed). */
#ifndef ELF64_H
#define ELF64_H
#include <stddef.h>
#include <stdint.h>

typedef struct so_mod {
  uint8_t  *rw;        /* writable view of the loaded image                    */
  uintptr_t rx;        /* address the image executes at (== rw on the host)    */
  size_t    size;      /* bytes spanned by all PT_LOAD segments                */
  uint64_t  phoff; uint16_t phnum;   /* program header table (inside the first PT_LOAD) */
  size_t    x_start, x_end;   /* page-aligned range of the executable (PF_X) segments, image-relative */
  /* dynamic info (offsets are image-relative vaddrs) */
  const uint8_t *symtab; const char *strtab; size_t nsyms;
  uintptr_t *init_array; size_t n_init;
  uintptr_t init_fn;
  /* stats filled in by so_relocate */
  size_t n_reloc, n_unresolved;
} so_mod;

/* Gives the loader memory: *rw must be zeroed, writable, 16-byte aligned. */
typedef int   (*so_alloc_fn)(size_t size, void **rw, uintptr_t *rx, void *ud);
/* Returns the host address for an imported symbol, or NULL if unknown. */
typedef void *(*so_resolve_fn)(const char *name, void *ud);
/* Called once for every symbol that resolve() could not satisfy. */
typedef void  (*so_unresolved_fn)(const char *name, void *ud);

int   so_load(so_mod *m, const void *file, size_t len, so_alloc_fn alloc, void *ud);
int   so_relocate(so_mod *m, so_resolve_fn res, so_unresolved_fn unres, void *stub, void *ud);
void *so_sym(const so_mod *m, const char *name);          /* exported symbol (rx address) */
void  so_rebase(so_mod *m);   /* after the image is mapped at rx: every internal pointer moves from the (now inaccessible) rw copy to rx */
void  so_run_init(so_mod *m);                             /* DT_INIT then DT_INIT_ARRAY   */
#endif
