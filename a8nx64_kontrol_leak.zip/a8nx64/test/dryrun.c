/* Host-side check: maps libAsphalt8.so, applies every relocation, and lists the imports that
 * the port's table (imports_names.txt) does not serve. Nothing from the .so is executed. */
#include "../source/elf64.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

static char **names; static size_t nn;
static int cmp(const void *a, const void *b) { return strcmp(*(char **)a, *(char **)b); }
static int alloc_fn(size_t sz, void **rw, uintptr_t *rx, void *ud) {
  void *p = mmap(0, sz, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (p == MAP_FAILED) return -1; *rw = p; *rx = (uintptr_t)p; return 0; }
static void *resolve(const char *n, void *ud) {
  return bsearch(&n, names, nn, sizeof *names, cmp) ? (void *)0x1 : NULL; }
static void unres(const char *n, void *ud) { printf("UNRESOLVED %s\n", n); }

int main(int argc, char **argv) {
  if (argc < 3) { fprintf(stderr, "usage: dryrun lib.so imports_names.txt\n"); return 2; }
  FILE *f = fopen(argv[2], "r"); char line[256]; names = malloc(sizeof(char *) * 4096);
  while (fgets(line, sizeof line, f)) { line[strcspn(line, "\n")] = 0; if (*line) names[nn++] = strdup(line); }
  fclose(f); qsort(names, nn, sizeof *names, cmp);
  f = fopen(argv[1], "rb"); fseek(f, 0, SEEK_END); long len = ftell(f); rewind(f);
  void *buf = malloc(len); if (fread(buf, 1, len, f) != (size_t)len) return 3; fclose(f);
  so_mod m; int r = so_load(&m, buf, len, alloc_fn, NULL);
  printf("so_load=%d size=0x%zx nsyms=%zu init_array=%zu\n", r, m.size, m.nsyms, m.n_init);
  if (r) return 1;
  r = so_relocate(&m, resolve, unres, (void *)0x2, NULL);
  printf("so_relocate=%d relocs=%zu unresolved=%zu\n", r, m.n_reloc, m.n_unresolved);
  printf("JNI_OnLoad at +0x%lx\n", (unsigned long)((uintptr_t)so_sym(&m, "JNI_OnLoad") - m.rx));
  return r ? 1 : 0;
}
