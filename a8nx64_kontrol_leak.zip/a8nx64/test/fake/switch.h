#ifndef FAKE_SWITCH_H
#define FAKE_SWITCH_H
#include <stddef.h>
/* host-only stand-in so bionic_shim.c can be syntax-checked without libnx */
#include <stdint.h>
typedef uint32_t u32; typedef uint64_t u64; typedef int64_t s64; typedef u32 Result;
typedef u32 Mutex; typedef u32 CondVar;
typedef struct { CondVar c; Mutex m; u64 n; } Semaphore;
#define R_FAILED(r) ((r) != 0)
int mutexTryLock(Mutex*); void *armGetTls(void);
void mutexLock(Mutex*); void mutexUnlock(Mutex*);
Result condvarWait(CondVar*, Mutex*); Result condvarWaitTimeout(CondVar*, Mutex*, u64);
Result condvarWakeOne(CondVar*); Result condvarWakeAll(CondVar*);
void semaphoreInit(Semaphore*, u64); void semaphoreSignal(Semaphore*); void semaphoreWait(Semaphore*);
void svcSleepThread(s64); u64 armGetSystemTick(void); u64 armGetSystemTickFreq(void);
typedef struct { int x; } Jit; Result jitCreate(Jit*, size_t); Result jitTransitionToWritable(Jit*); Result jitTransitionToExecutable(Jit*);
void *jitGetRwAddr(Jit*); void *jitGetRxAddr(Jit*); void consoleInit(void*); void consoleUpdate(void*); void consoleExit(void*);
typedef u32 Handle; enum { Perm_Rw = 3, Perm_Rx = 5 };
Handle envGetOwnProcessHandle(void); void *virtmemFindCodeMemory(size_t, size_t);
Result svcMapProcessCodeMemory(Handle, u64, u64, u64); Result svcSetProcessMemoryPermission(Handle, u64, u64, u32);
enum { InfoType_TotalMemorySize = 6, InfoType_UsedMemorySize = 7 }; 
#define CUR_PROCESS_HANDLE 0xFFFF8001
Result svcGetInfo(u64*, u32, Handle, u64); void *virtmemFindAslr(size_t, size_t);
typedef struct { u64 addr, size; u32 type, attr, perm, ipc_refcount, device_refcount, padding; } MemoryInfo;
enum { InfoType_AslrRegionAddress = 2, InfoType_AslrRegionSize = 3, MemType_Unmapped = 0 };
Result svcQueryMemory(MemoryInfo*, u32*, u64);
enum { ArbitrationType_WaitIfEqual = 2, SignalType_Signal = 0 };
Result svcWaitForAddress(void*, u32, int, s64); Result svcSignalToAddress(void*, u32, int, int); void randomGet(void*, size_t);
typedef struct { u64 buttons_cur; } PadState; typedef struct { int x, y; } HidAnalogStickState;
enum { HidNpadButton_A=1, HidNpadButton_B=2, HidNpadButton_X=4, HidNpadButton_Y=8, HidNpadButton_StickL=16, HidNpadButton_StickR=32, HidNpadButton_L=64, HidNpadButton_R=128,
 HidNpadButton_ZL=256, HidNpadButton_ZR=512, HidNpadButton_Plus=1024, HidNpadButton_Minus=2048, HidNpadButton_Left=4096, HidNpadButton_Up=8192, HidNpadButton_Right=16384, HidNpadButton_Down=32768 };
u64 padGetButtons(const PadState*); HidAnalogStickState padGetStickPos(const PadState*, unsigned);
#endif
