# Perubahan: kontrol gamepad + pelacak kebocoran memori

## 1. Kontrol (source/controls.c, controls.h, game.c)
- `/switch/a8nx64/controls.ini` dibuat otomatis saat pertama jalan; diubah saat game berjalan (dibaca ulang tiap ~2 detik).
- `mode = keys | touch | both`: tombol -> keycode gamepad Android (`nativeKeyAction`) atau ketukan jari palsu (`NativeOnTouch`, id 32+).
- Stick kiri -> DPAD kiri/kanan (kemudi), opsional juga ke `accelerometerEvent` (`accel = 1`).
- Keluar: tahan MINUS+PLUS (PLUS sendiri sekarang dikirim ke game sebagai START, tidak lagi keluar).
- BELUM DIUJI di Switch. `nativeKeyAction` dan `accelerometerEvent` ditebak berparameter (int,int) dan (float,float,float);
  `key_order` di ini membalik urutan argumen. Event pertama dicatat di debug.log (`[ctl] ...`).
- Koordinat `[touch]` hanyalah tempat penampung: sesuaikan dengan tata letak layar sentuh game.

## 2. Kebocoran memori
- Pelacak: `bionic_shim.c` mencatat setiap blok >= 1 MB dari malloc/calloc/realloc/posix_memalign beserta pemanggilnya;
  `free`/`sdallocx` kini lewat `b_free` (imports_gen.c diubah: `free` -> `b_free`; generator akan menghasilkannya sendiri).
- Laporan tiap 5 detik ke `debug.log` ([leak]) dan `/switch/a8nx64/leak.txt`: blok hidup per pemanggil, jumlah, ukuran, umur tertua.
  Pemanggil yang jumlahnya terus naik = sumber kebocoran. Dugaan utama: `img+0x21445c0` (blok 13.342 KB).
- Arena mmap dikecilkan 768 MB -> 256 MB (log: puncak pemakaian 6 MB, tidak pernah penuh).
