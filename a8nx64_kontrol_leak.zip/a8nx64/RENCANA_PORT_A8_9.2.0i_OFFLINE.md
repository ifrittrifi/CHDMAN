# Rencana port Asphalt 8 9.2.0i ke Switch (64-bit, offline, tanpa iklan)

Status: rencana + hasil analisis. Belum ada build yang dikompilasi atau diuji di Switch.

## 1. Data yang sudah dipastikan
- APK: hanya arm64-v8a (22 .so), 18 dex, package com.gameloft.android.ANMP.GloftA8HM.
- Data game: 1.696 file, 2,65 GB, dari Play Asset Delivery (assetpacks/<pack>/92009/92009/assets/data/*.jpk):
  models_pack 888 MB, textures_pack1-3 1,29 GB, music_pack 269 MB (music.jpk 183 MB, sounds.jpk 86 MB),
  common_pack 204 MB (pvs.jpk 85 MB, 768 file kecil), plus _metadata/*.dat (775+ file kecil; 0-NAM.dat, N-LFH.dat, properties.dat).
- Folder _metadata dipakai oleh Play Asset Delivery. Perlu dicek di uji pertama apakah engine membacanya atau cukup assets/data/*.jpk.

## 2. Lapisan JNI (dari dex, lihat jni_native_methods_dari_dex.txt)
### Dipertahankan (butuh jalan di Switch)
- GL2JNILib: init, initGL, step, resize, touchEvent, accelerometerEvent, setPaths, onPause/onResume, orientationChanged, stateChanged, destroy, FreeMemory, nativeKeyAction, getViewSettings, setNumExtraContext/getNumExtraContext, nativeSetPower*Joystick, nativeSetStatus*
- JNIBridge: NativeInit, SetActivity, NativeOnTouch, NativeKeyAction, NativeSurfaceChanged, NativeOnPause/OnResume, NativeVolumeAction, NativeAudioFocusChanged, SetBatteryInfo, SetConnectionType, OnDeviceResolutionChanged, NotifyTrimMemory
- NativeBridgeHIDControllers: NativeControllerConnected/Disconnected, NativeHandleInputEvents
- MainActivity.setOpenGlesVersion, NativeCheckGLVersionGPU
### Di-stub (tidak ada fungsi di Switch offline; kembalikan nilai kosong/sukses)
- Iklan: adsmanager/*, glads/*, audioadsutils, audiomobwrapper, odeeowrapper, popupslib, OmSDK, MoatSDK
- Consent/legal: cmp/*, didomiwrapper/*, legal/*, AgeValidator
- Toko dan akun: iab/* (InAppBilling, GMPUtils), GLSocialLib (Facebook, Discord, GameAPI), OLPInstallReferrer, Helpshift, InGameBrowser, PushNotification, hdidfv, antihack, EmulatorDetector, LocationDetector
- Firebase C++, Crashlytics, apminsight, applovin crash reporter, tapjoy, discord_partner_sdk: tidak dimuat; resolver simbol mengembalikan stub
- SetConnectionType selalu "tidak ada jaringan"; semua socket/getaddrinfo gagal dengan cepat (offline 100%)

## 3. Catatan offline
- libAsphalt8.so berisi libcurl dan cache HSTS. Dengan koneksi dilaporkan mati dan DNS gagal, engine seharusnya masuk mode offline. Perlu diverifikasi di perangkat bahwa tidak ada layar loading yang menunggu server (pop-up, update data, login).
- Fitur yang bergantung server (event online, multiplayer, toko) tidak akan jalan. Ini sesuai permintaan.
- Item premium/toko offline bergantung data lokal; pembelian dinonaktifkan.

## 4. Pekerjaan teknis (urutan)
1. Proyek devkitA64 + libnx 64-bit + Mesa/EGL bawaan devkitPro.
2. Loader ELF64: PT_LOAD, RELA (R_AARCH64_RELATIVE/GLOB_DAT/JUMP_SLOT/ABS64), TLS, init_array, RegisterNatives lewat JNI_OnLoad.
3. Shim bionic 64-bit + 224 import yang belum ada (import_belum_ada.txt). Catatan: libc++ dari libAsphalt8 membutuhkan libc++_shared atau symbol __cxa_*.
4. JNIEnv tiruan untuk daftar bagian 2.
5. GLES: engine memakai EGL/GLES; periksa versi (2.0/3.x) dan ekstensi yang diminta.
6. Audio: OpenSL ES -> audout; Input: HID -> touch/joystick.
7. Path data: setPaths -> /switch/<nama>/assetpacks/...
8. Uji bertahap: loader sampai JNI_OnLoad, lalu init, lalu menu, lalu balapan.

## 5. Tidak bisa dilakukan dari sesi ini
Tidak ada compiler Switch, tidak ada jaringan paket, tidak ada perangkat uji.
