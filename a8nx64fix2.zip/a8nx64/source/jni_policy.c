/* jni_policy.c -- what Java would answer. Everything not listed gets 0 / false / "" / null and is logged
 * ("JNI call ...") so debug.log shows exactly which calls the engine makes. Keep this file small:
 * only add answers the game really needs. */
#include "jni_fake.h"
#include <string.h>

/* Data paths are relative to the SD card folder chosen by the launcher. */
#define DATA_ROOT "/switch/a8nx64/data"

int jni_policy_int(const char *cls, const char *name, const char *sig, int dflt) {
  if (!strcmp(name, "isNetworkAvailable") || !strcmp(name, "isConnected") || !strcmp(name, "isOnline")) return 0;
  if (!strcmp(name, "getConnectionType")) return 0;         /* no network: engine stays offline */
  if (!strcmp(name, "GetAPILevel")) return 30;
  if (!strcmp(name, "GetIsNeedDownload")) return 0;
  if (!strcmp(name, "GetIsCompleteCheck")) return 1;      /* the engine polls this until "data check complete" */
  /* Without these the engine saw "0 KB free" -> "you don't have enough free space" + ExitApplication,
   * and a 0 MB / 0 MHz / 0 core device -> lowest quality tier. KB values fit an int (2 GB max in KB = 2 TB). */
  if (!strcmp(name, "GetFreeSpaceInKBytes") || !strcmp(name, "GetFreeSpaceSDInKBytes")) return 16 * 1024 * 1024;   /* 16 GB */
  if (!strcmp(name, "GetPhoneMemory")) return 4096;           /* MB (Switch has ~4 GB); logged as a J (long) call */
  if (!strcmp(name, "GetMaxCPUCore")) return 4;
  if (!strcmp(name, "GetPhoneWidth")) return 1280;
  if (!strcmp(name, "GetPhoneHeight")) return 720;
  if (!strcmp(name, "HasConnectivity")) return 0;
  return dflt;
}
float jni_policy_float(const char *cls, const char *name, const char *sig) {
  if (!strcmp(name, "GetMaxCPUSpeed")) return 1020.0f;       /* MHz */
  if (!strcmp(name, "GetWidth")) return 1280.0f;
  if (!strcmp(name, "GetHeight")) return 720.0f;
  if (!strcmp(name, "GetXDpi") || !strcmp(name, "GetYDpi")) return 237.0f;   /* Switch 6.2" 720p */
  if (!strcmp(name, "GetWidthInInch")) return 5.4f;
  if (!strcmp(name, "GetHeightInInch")) return 3.0f;
  if (!strcmp(name, "GetUsedApplicationMemory")) return 512.0f;
  return 0.0f;
}
const char *jni_policy_string(const char *cls, const char *name, const char *sig) {
  if (!strcmp(name, "getAbsolutePath") || !strcmp(name, "getFilesDir") || !strcmp(name, "getDataDir")) return DATA_ROOT;
  if (!strcmp(name, "getPackageName")) return "com.gameloft.android.ANMP.GloftA8HM";
  if (!strcmp(name, "getLanguage")) return "en";
  if (!strcmp(name, "getCountry")) return "US";
  if (strstr(name, "PackPath")) return DATA_ROOT "/";
  if (!strncmp(name, "Retrieve", 8)) return !strcmp(name, "RetrieveNativeLibraryPath") ? "/switch/a8nx64/lib" : DATA_ROOT;
  if (!strcmp(name, "GetDeviceManufacturer")) return "Nintendo";
  if (!strcmp(name, "GetDeviceModel") || !strcmp(name, "GetPhoneProduct") || !strcmp(name, "GetPhoneDevice")) return "Switch";
  if (!strcmp(name, "GetCPUAbi")) return "arm64-v8a";
  if (!strcmp(name, "GetFirmware")) return "11";
  if (!strcmp(name, "GetApkPath") || !strcmp(name, "GetApkPathsSingleString")) return "/switch/a8nx64/apk/base.apk";
  if (!strcmp(name, "GetGameName")) return "Asphalt 8";
  if (!strcmp(name, "GetAndroidID") || !strcmp(name, "GetSerial") || !strcmp(name, "GetCPUSerial")) return "0000000000000001";
  return "";
}
