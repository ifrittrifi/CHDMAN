/* bionic_shim.c -- the b_<name> functions that stand in for Android's libc where its ABI differs from
 * newlib's (AArch64). gen_imports.py wires every b_<name> defined here into the import table.
 * Layouts used (bionic LP64): pthread_mutex_t 40 B, pthread_cond_t 48 B, sem_t 32 B, pthread_rwlock_t 56 B.
 * The libnx primitives live at byte offset 8 of each object; the zero-filled bionic initializers
 * (PTHREAD_MUTEX_INITIALIZER etc.) therefore work as is. UNTESTED ON HARDWARE. */
#include "jni_fake.h"
#include <errno.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <switch.h>
#include <pthread.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include "imports.h"
extern void *memalign(size_t, size_t);   /* newlib; avoids relying on aligned_alloc being declared */
#ifndef DT_DIR
#define DT_DIR 4
#endif

extern void jni_log(const char *fmt, ...);

/* ---- errno, logging, assert ------------------------------------------------------------------ */
int *b___errno(void) { return &errno; }
int b___android_log_print(int prio, const char *tag, const char *fmt, ...) {
  char b[1024]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof b, fmt, a); va_end(a);
  jni_log("[%s] %s", tag ? tag : "?", b); return 0; }
int b___android_log_vprint(int prio, const char *tag, const char *fmt, va_list a) {
  char b[1024]; vsnprintf(b, sizeof b, fmt, a); jni_log("[%s] %s", tag ? tag : "?", b); return 0; }
int b___android_log_write(int prio, const char *tag, const char *msg) { jni_log("[%s] %s", tag, msg); return 0; }
void b___assert2(const char *file, int line, const char *func, const char *expr) {
  jni_log("ASSERT %s:%d %s: %s", file, line, func, expr); abort(); }
extern void *g_main_tls;
/* abort() in a game worker thread (std::terminate after an uncaught exception, e.g. a failed network call) ends only that thread. */
void b_abort(void) { { extern unsigned long long g_game_img; jni_log("[abort] caller=img+0x%llx", (unsigned long long)__builtin_return_address(0) - g_game_img); }
  int main_thr = (armGetTls() == g_main_tls);
  jni_log("[abort] abort() called from %s thread", main_thr ? "MAIN" : "worker");
  if (!main_thr) { svcExitThread(); for (;;) svcSleepThread(1000000000ll); }
  _exit(134); }
void b_android_set_abort_message(const char *m) { jni_log("ABORT %s", m ? m : ""); }
int b___system_property_get(const char *n, char *v) { v[0] = 0; return 0; }   /* no Android properties */

/* ---- stdio: bionic exposes stdin/stdout/stderr through the __sF array ------------------------- */
char b___sF[3 * 152];                                  /* bionic's stdin/stdout/stderr array; only addresses matter */
static FILE *fx(void *f) {                             /* map bionic's std streams onto newlib's */
  if (!f) { static FILE *nf; if (!nf) nf = fopen("/switch/a8nx64/null.bin", "w+"); return nf ? nf : stderr; }   /* games use NULL FILE* after a failed fopen */
  char *c = f; if (c >= b___sF && c < b___sF + sizeof b___sF) { int i = (c - b___sF) / 152; return i == 0 ? stdin : i == 1 ? stdout : stderr; }
  return f; }
size_t b_fwrite(const void *p, size_t a, size_t n, void *f) { return fwrite(p, a, n, fx(f)); }
int b_fputs(const char *s, void *f) { return fputs(s, fx(f)); }
int b_fputc(int c, void *f) { return fputc(c, fx(f)); }
int b_putc(int c, void *f) { return fputc(c, fx(f)); }
int b_fflush(void *f) { return fflush(f ? fx(f) : NULL); }
char *b_fgets(char *s, int n, void *f) { return fgets(s, n, fx(f)); }
int b_fgetc(void *f) { return fgetc(fx(f)); }
int b_getc(void *f) { return fgetc(fx(f)); }
int b_ungetc(int c, void *f) { return ungetc(c, fx(f)); }
int b_ferror(void *f) { return ferror(fx(f)); }
int b_feof(void *f) { return feof(fx(f)); }
void b_clearerr(void *f) { clearerr(fx(f)); }
int b_fileno(void *f) { return fileno(fx(f)); }
int b_vfprintf(void *f, const char *fmt, va_list a) { return vfprintf(fx(f), fmt, a); }
int b_fprintf(void *f, const char *fmt, ...) { va_list a; va_start(a, fmt); int r = vfprintf(fx(f), fmt, a); va_end(a); return r; }

/* ---- pthread primitives ----------------------------------------------------------------------- */
/* Own recursive mutex over libnx's plain Mutex: layout inside the 40-byte bionic object, offset 8. */
typedef struct { Mutex lock; u32 owner; u32 count; } bmtx;
#define MTX(m)  ((bmtx *)((uint8_t *)(m) + 8))
#define CND(c)  ((CondVar *)((uint8_t *)(c) + 8))
static inline u32 self_id(void) { return (u32)(uintptr_t)armGetTls(); }
static void bm_lock(bmtx *m)   { u32 me = self_id(); if (m->owner == me && m->count) { m->count++; return; }
                                 mutexLock(&m->lock); m->owner = me; m->count = 1; }
static int  bm_trylock(bmtx *m){ u32 me = self_id(); if (m->owner == me && m->count) { m->count++; return 1; }
                                 if (!mutexTryLock(&m->lock)) return 0; m->owner = me; m->count = 1; return 1; }
static void bm_unlock(bmtx *m) { if (--m->count == 0) { m->owner = 0; mutexUnlock(&m->lock); } }
int b_pthread_mutex_init(void *m, const void *attr) { memset(m, 0, 40); return 0; }
int b_pthread_mutex_destroy(void *m) { return 0; }
int b_pthread_mutex_lock(void *m)    { bm_lock(MTX(m)); return 0; }
int b_pthread_mutex_trylock(void *m) { return bm_trylock(MTX(m)) ? 0 : EBUSY; }
int b_pthread_mutex_unlock(void *m)  { bm_unlock(MTX(m)); return 0; }
int b_pthread_mutexattr_init(int *a) { *a = 0; return 0; }
int b_pthread_mutexattr_destroy(int *a) { return 0; }
int b_pthread_mutexattr_settype(int *a, int t) { *a = t; return 0; }
int b_pthread_mutexattr_gettype(const int *a, int *t) { *t = *a; return 0; }

int b_pthread_cond_init(void *c, const void *attr) { memset(c, 0, 48); if (attr) *(int *)c = *(const int *)attr; return 0; }
int b_pthread_cond_destroy(void *c) { return 0; }
int b_pthread_cond_signal(void *c)    { condvarWakeOne(CND(c)); return 0; }
int b_pthread_cond_broadcast(void *c) { condvarWakeAll(CND(c)); return 0; }
int b_clock_gettime(int clk, struct timespec *ts);
static int cond_wait(void *c, void *m, int64_t ns) {
  bmtx *bm = MTX(m); u32 cnt = bm->count;                /* caller holds the mutex (possibly recursively) */
  bm->owner = 0; bm->count = 0;                          /* the condvar releases and re-takes bm->lock */
  Result rc = ns < 0 ? condvarWait(CND(c), &bm->lock) : condvarWaitTimeout(CND(c), &bm->lock, (u64)ns);
  bm->owner = self_id(); bm->count = cnt;
  return R_FAILED(rc) && ns >= 0 ? 110 /* bionic ETIMEDOUT; newlib uses 116 and libc++ would throw system_error */ : 0; }
int b_pthread_cond_wait(void *c, void *m) { return cond_wait(c, m, -1); }
int b_pthread_cond_timedwait(void *c, void *m, const struct timespec *abs) {
  struct timespec now; b_clock_gettime(*(int *)c == 1 ? 1 : 0, &now);   /* clock chosen via condattr_setclock */
  int64_t ns = ((int64_t)abs->tv_sec - now.tv_sec) * 1000000000ll + abs->tv_nsec - now.tv_nsec;
  return cond_wait(c, m, ns < 0 ? 0 : ns); }
int b_pthread_condattr_init(void *a) { *(int *)a = 0; return 0; }
int b_pthread_condattr_setclock(void *a, int clk) { *(int *)a = clk; return 0; }

int b_sem_init(void *s, int shared, unsigned v) { memset(s, 0, 32); semaphoreInit((Semaphore *)((uint8_t *)s + 8), v); return 0; }
int b_sem_destroy(void *s) { return 0; }
int b_sem_post(void *s) { semaphoreSignal((Semaphore *)((uint8_t *)s + 8)); return 0; }
int b_sem_wait(void *s) { semaphoreWait((Semaphore *)((uint8_t *)s + 8)); return 0; }

int b_pthread_rwlock_init(void *l, const void *a) { memset(l, 0, 56); return 0; }
int b_pthread_rwlock_destroy(void *l) { return 0; }
int b_pthread_rwlock_rdlock(void *l) { bm_lock(MTX(l)); return 0; }   /* readers serialise: safe, slower */
int b_pthread_rwlock_wrlock(void *l) { bm_lock(MTX(l)); return 0; }
int b_pthread_rwlock_unlock(void *l) { bm_unlock(MTX(l)); return 0; }

static Mutex g_once_lock;
int b_pthread_once(volatile int *o, void (*fn)(void)) {
  mutexLock(&g_once_lock); int run = (*o == 0); if (run) *o = 1; mutexUnlock(&g_once_lock);
  if (run) { fn(); __sync_synchronize(); *o = 2; } else while (*o != 2) svcSleepThread(100000);
  return 0; }
/* bionic/AArch64 keeps its TLS block at TPIDR_EL0: slot 0 = self, slot 5 (+0x28) = the stack-protector canary,
 * which compiled game code reads at the start of every protected function. Horizon leaves TPIDR_EL0 at 0,
 * so every thread that runs game code gets a block (the toolchain here uses -mtp=soft: it does not use TPIDR_EL0). */
#define KEYS_MAX 1024
void bionic_tls_setup(void) {
  uint64_t *b = calloc(64 + KEYS_MAX, sizeof(uint64_t));   /* slots 0..63: bionic; 64..: pthread_key values */
  if (!b) abort();
  b[0] = (uint64_t)(uintptr_t)b;                       /* TLS_SLOT_SELF */
  b[1] = (uint64_t)(uintptr_t)armGetTls();             /* TLS_SLOT_THREAD_ID */
  b[5] = 0x5a17c0de6e0bf00dull;                        /* TLS_SLOT_STACK_GUARD */
  __asm__ volatile("msr tpidr_el0, %0" :: "r"(b) : "memory"); }
/* pthread keys: libnx/newlib runs out of keys quickly (libc++'s __thread_specific_ptr then throws), so the keys live
 * in each thread's bionic block. Destructors are not run at thread exit (nothing the game needs). */
static int g_nkeys;
int b_pthread_key_create(uint32_t *k, void (*d)(void *)) { int i = __atomic_fetch_add(&g_nkeys, 1, __ATOMIC_SEQ_CST); if (i >= KEYS_MAX) { g_nkeys = KEYS_MAX; return 11; } *k = (uint32_t)i; return 0; }
int b_pthread_key_delete(uint32_t k) { return 0; }
static uint64_t *tls_block(void) { uint64_t t; __asm__ volatile("mrs %0, tpidr_el0" : "=r"(t)); return (uint64_t *)t; }
void *b_pthread_getspecific(uint32_t k) { uint64_t *b = tls_block(); return (b && k < KEYS_MAX) ? (void *)b[64 + k] : NULL; }
int b_pthread_setspecific(uint32_t k, const void *v) { uint64_t *b = tls_block(); if (!b || k >= KEYS_MAX) return 22; b[64 + k] = (uint64_t)v; return 0; }
int g_nthr; unsigned g_thr_h[64]; unsigned long long g_thr_fn[64];
typedef struct { void *(*fn)(void *); void *arg; int idx; } thr_start_t;
void *g_thr_tls[64];
static void *thr_tramp(void *p) { thr_start_t s = *(thr_start_t *)p; free(p); bionic_tls_setup(); { int core = (s.idx + 1) % 3; Result cr = svcSetThreadCoreMask(threadGetCurHandle(), core, 1u << core); if (s.idx < 4) jni_log("[thread] #%d core=%d rc=0x%x main_core=%d", s.idx, core, cr, (int)svcGetCurrentProcessorNumber()); } if (s.idx < 64) g_thr_tls[s.idx] = armGetTls(); void *r = s.fn(s.arg); { extern unsigned long long g_game_img; jni_log("[thread] ended fn=img+0x%llx ret=%p", (unsigned long long)s.fn - g_game_img, r); } return r; }
int b_pthread_create(uint64_t *t, const void *attr, void *(*fn)(void *), void *arg) {
  pthread_t tmp = 0; pthread_attr_t pa; pthread_attr_init(&pa);
  size_t ss = attr ? *(const uint64_t *)((const uint8_t *)attr + 8) : (1u << 20); if (ss < (1u << 20)) ss = 1u << 20; ss *= 4; pthread_attr_setstacksize(&pa, ss);   /* libnx stacks sit in the heap: an overflow corrupts neighbours, so be generous */
  thr_start_t *ts = malloc(sizeof *ts); ts->fn = fn; ts->arg = arg; ts->idx = g_nthr;
  int r = pthread_create(&tmp, &pa, thr_tramp, ts); pthread_attr_destroy(&pa); *t = (uint64_t)tmp;
  { extern unsigned long long g_game_img; int i = __atomic_fetch_add(&g_nthr, 1, __ATOMIC_SEQ_CST);
    if (i < 64) { g_thr_h[i] = r == 0 && tmp ? *(uint32_t *)tmp : 0; g_thr_fn[i] = (unsigned long long)fn - g_game_img; }
    jni_log("[thread] #%d create fn=img+0x%llx stack=0x%zx handle=0x%x -> %d", i, (unsigned long long)fn - g_game_img, ss, i < 64 ? g_thr_h[i] : 0, r); }
  return r; }
int b_pthread_join(uint64_t t, void **ret) { return pthread_join((pthread_t)t, ret); }
int b_pthread_detach(uint64_t t) { return pthread_detach((pthread_t)t); }
uint64_t b_pthread_self(void) { return (uint64_t)pthread_self(); }
int b_sched_yield(void) { svcSleepThread(0); return 0; }
int b_usleep(unsigned us) { svcSleepThread((s64)us * 1000); return 0; }
int b_nanosleep(const struct timespec *r, struct timespec *o) { svcSleepThread((s64)r->tv_sec * 1000000000ll + r->tv_nsec); return 0; }

/* ---- time: bionic clock ids (REALTIME 0, MONOTONIC 1) ------------------------------------------ */
int b_clock_gettime(int clk, struct timespec *ts) {
  u64 tick = armGetSystemTick(), hz = armGetSystemTickFreq();
  if (clk == 0) { struct timeval tv; gettimeofday(&tv, 0); ts->tv_sec = tv.tv_sec; ts->tv_nsec = tv.tv_usec * 1000; return 0; }
  ts->tv_sec = tick / hz; ts->tv_nsec = (tick % hz) * 1000000000ull / hz; return 0; }
long b_sysconf(int name) { switch (name) { case 0x27: case 0x28: return 4096; /* _SC_PAGESIZE */
                                            case 0x61: case 0x60: return 4;  /* _SC_NPROCESSORS_* */ default: return -1; } }
char *b_getenv(const char *n) { return NULL; }

/* ---- network: the game is offline, every attempt fails fast ------------------------------------ */
#define NO_NET(name, ...) int b_##name(__VA_ARGS__) { errno = ENETDOWN; return -1; }
NO_NET(socket, int d, int t, int p)
NO_NET(connect, int s, const void *a, unsigned l)
int b_getaddrinfo(const char *h, const char *s, const void *hints, void **res) { *res = 0; return -2; /* EAI_NONAME */ }
void b_freeaddrinfo(void *r) {}
int b_getnameinfo(const void *sa, unsigned l, char *h, unsigned hl, char *s, unsigned sl, int f) { return -2; }

/* ---- more libc: auxv, fortify, files, dirs, memory, dl ------------------------------------------ */
unsigned long b_getauxval(unsigned long t) { return t == 16 ? 3 /*HWCAP FP|ASIMD*/ : t == 6 ? 4096 : 0; }
void b___stack_chk_fail(void) { jni_log("__stack_chk_fail"); abort(); }
void *b___memcpy_chk(void *d, const void *s, size_t n, size_t dl) { return memcpy(d, s, n); }
void *b___memmove_chk(void *d, const void *s, size_t n, size_t dl) { return memmove(d, s, n); }
void *b___memset_chk(void *d, int c, size_t n, size_t dl) { return memset(d, c, n); }
char *b___strcpy_chk(char *d, const char *s, size_t dl) { return strcpy(d, s); }
char *b___strcat_chk(char *d, const char *s, size_t dl) { return strcat(d, s); }
size_t b___strlen_chk(const char *s, size_t dl) { return strlen(s); }
char *b___strchr_chk(const char *s, int c, size_t dl) { return strchr(s, c); }
int b___vsnprintf_chk(char *d, size_t m, int fl, size_t dl, const char *f, va_list a) { return vsnprintf(d, m, f, a); }
int b___vsprintf_chk(char *d, int fl, size_t dl, const char *f, va_list a) { return vsprintf(d, f, a); }

#define RANDOM_FD 0x4ffff                                /* stands in for /dev/urandom and /dev/random */

/* ---- epoll / eventfd emulation (asio's reactor and wake-up pipe need them; sockets stay unavailable) ---- */
#define FK_BASE 0x50000
#define FK_N 64
typedef struct { int type; uint64_t cnt; int flags; int nint; struct { int fd; uint32_t ev; uint64_t data; } in[16]; } fk_t;   /* type 1 epoll, 2 eventfd */
static fk_t g_fk[FK_N]; static volatile int g_fk_lock;
static void fk_lock(void) { while (__atomic_exchange_n(&g_fk_lock, 1, __ATOMIC_ACQUIRE)) svcSleepThread(100000); }
static void fk_unlock(void) { __atomic_store_n(&g_fk_lock, 0, __ATOMIC_RELEASE); }
static fk_t *fk_get(int fd) { return (fd >= FK_BASE && fd < FK_BASE + FK_N && g_fk[fd - FK_BASE].type) ? &g_fk[fd - FK_BASE] : NULL; }
static int fk_new(int type, uint64_t cnt, int flags) {
  fk_lock(); for (int i = 0; i < FK_N; i++) if (!g_fk[i].type) { memset(&g_fk[i], 0, sizeof g_fk[i]); g_fk[i].type = type; g_fk[i].cnt = cnt; g_fk[i].flags = flags; fk_unlock(); return FK_BASE + i; }
  fk_unlock(); errno = 24; return -1; }
int b_epoll_create(int s) { return fk_new(1, 0, 0); }
int b_epoll_create1(int f) { return fk_new(1, 0, 0); }
int b_eventfd(unsigned i, int f) { return fk_new(2, i, f); }
int b_epoll_ctl(int ep, int op, int fd, void *evp) {
  fk_t *e = fk_get(ep); if (!e || e->type != 1) { errno = 9; return -1; }
  uint32_t ev = evp ? *(uint32_t *)evp : 0; uint64_t data = evp ? *(uint64_t *)((char *)evp + 8) : 0; int r = 0;
  fk_lock();
  int idx = -1; for (int i = 0; i < e->nint; i++) if (e->in[i].fd == fd) idx = i;
  if (op == 1) { if (idx >= 0) { errno = 17; r = -1; } else if (e->nint >= 16) { errno = 28; r = -1; } else { e->in[e->nint].fd = fd; e->in[e->nint].ev = ev; e->in[e->nint].data = data; e->nint++; } }
  else if (op == 2) { if (idx < 0) { errno = 2; r = -1; } else { e->in[idx] = e->in[--e->nint]; } }
  else if (op == 3) { if (idx < 0) { errno = 2; r = -1; } else { e->in[idx].ev = ev; e->in[idx].data = data; } }
  fk_unlock(); return r; }
int b_epoll_wait(int ep, void *out, int max, int timeout) {
  fk_t *e = fk_get(ep); if (!e || e->type != 1 || max <= 0) { errno = 9; return -1; }
  uint64_t t0 = armGetSystemTick(), freq = armGetSystemTickFreq();
  for (;;) {
    int n = 0; fk_lock();
    for (int i = 0; i < e->nint && n < max; i++) { fk_t *f = fk_get(e->in[i].fd);
      if (f && f->type == 2 && f->cnt && (e->in[i].ev & 1)) { char *o = (char *)out + 16 * n; memset(o, 0, 16); *(uint32_t *)o = 1; *(uint64_t *)(o + 8) = e->in[i].data; n++; } }
    fk_unlock();
    if (n) return n;
    if (timeout == 0) return 0;
    if (timeout > 0 && (armGetSystemTick() - t0) * 1000 / freq >= (uint64_t)timeout) return 0;
    svcSleepThread(1000000); } }
int b_eventfd_write(int fd, unsigned long v) { fk_t *f = fk_get(fd); if (!f || f->type != 2) { errno = 9; return -1; } fk_lock(); f->cnt += v; fk_unlock(); return 0; }
int b_eventfd_read(int fd, void *v) {
  fk_t *f = fk_get(fd); if (!f || f->type != 2) { errno = 9; return -1; }
  for (;;) { fk_lock(); if (f->cnt) { *(uint64_t *)v = f->cnt; f->cnt = 0; fk_unlock(); return 0; } fk_unlock();
    if (f->flags & 04000) { errno = 11; return -1; } svcSleepThread(1000000); } }
int b_write(int fd, const void *b, size_t n) {
  if (fk_get(fd)) { if (n != 8) { errno = 22; return -1; } return b_eventfd_write(fd, *(const uint64_t *)b) ? -1 : 8; }
  return (int)write(fd, b, n); }
unsigned long long g_io_bytes, g_io_calls;
int b_read(int fd, void *buf, size_t n) {
  if (fk_get(fd)) { if (n < 8) { errno = 22; return -1; } return b_eventfd_read(fd, buf) ? -1 : 8; } if (fd == RANDOM_FD) { randomGet(buf, n); return (int)n; } { int r = (int)read(fd, buf, n); if (r > 0) { __atomic_fetch_add(&g_io_bytes, r, __ATOMIC_RELAXED); __atomic_fetch_add(&g_io_calls, 1, __ATOMIC_RELAXED); } return r; } }
int b_close(int fd) { if (fd == RANDOM_FD) return 0; fk_t *f = fk_get(fd); if (f) { fk_lock(); f->type = 0; fk_unlock(); return 0; } return close(fd); }
static const char *sdpath(const char *p, char *buf) {   /* the engine sometimes builds "/xyz" from an empty base path: keep those inside our folder */
  static const char *ok[] = {"/switch", "/sdmc", "/proc", "/sys", "/system", "/dev", "/etc", "/tmp", "/mnt", "/storage", "/vendor", "/rom", NULL};
  if (!p || p[0] != '/') return p; if (p[1] == '/') p++;
  if (p[1] == 0) return p;
  for (int i = 0; ok[i]; i++) { size_t n = strlen(ok[i]); if (!strncmp(p, ok[i], n) && (p[n] == '/' || p[n] == 0)) return p; }
  snprintf(buf, 600, "/switch/a8nx64/data/files%s", p); return buf; }
static void flog(const char *op, const char *p, long r) { static int n; if (n < 6000 && p && !strstr(p, "gv3/") && !strstr(p, "compliancy") && !strstr(p, "/sys/") && !strstr(p, "qacheck")) { n++; jni_log("[file] %s %s -> %ld", op, p, r); } }
FILE *b_fopen(const char *p0, const char *m) { char fb[640]; const char *p = sdpath(p0, fb); FILE *f = fopen(p, m); flog("fopen", p, f ? 1 : 0); return f; }
int b_pipe(int fd[2]) { errno = 24; return -1; }                /* EMFILE: no pipes on Horizon */
int b_pipe2(int fd[2], int fl) { errno = 24; return -1; }
int b_open(const char *p0, int f, ...) {                 /* bionic/Linux O_* values -> newlib's */
  char fb[640]; const char *p = sdpath(p0, fb);
  if (p && (!strcmp(p, "/dev/urandom") || !strcmp(p, "/dev/random"))) return RANDOM_FD;
  int m = 0; if (f & 0100) { va_list a; va_start(a, f); m = va_arg(a, int); va_end(a); }
  int n = f & 3; if (f & 0100) n |= O_CREAT; if (f & 0200) n |= O_EXCL; if (f & 01000) n |= O_TRUNC; if (f & 02000) n |= O_APPEND;
  flog("open>", p, f); int r = open(p, n, m); flog("open", p, r); return r; }
int b___open_2(const char *p, int f) { return b_open(p, f, 0644); }
int b___openat_2(int d, const char *p, int f) { return b_open(p, f, 0644); }
int b_openat(int d, const char *p, int f, ...) { return b_open(p, f, 0644); }   /* AT_FDCWD / absolute paths only */
int b_access(const char *p0, int m) { char fb[640]; const char *p = sdpath(p0, fb); int r = access(p, m); flog("access", p, r); return r; }
void *b_opendir(const char *p0) { char fb[640]; const char *p = sdpath(p0, fb); void *r = opendir(p); flog("opendir", p, r ? 1 : 0); return r; }
int b_mkdir(const char *p0, unsigned m) { char fb[640]; const char *p = sdpath(p0, fb); int r = mkdir(p, m); flog("mkdir", p, r); return r; }
int b_unlink(const char *p0) { char fb[640]; const char *p = sdpath(p0, fb); int r = unlink(p); flog("unlink", p, r); return r; }
int b_rename(const char *a, const char *b) { int r = rename(a, b); flog("rename", a, r); return r; }
char *b_realpath(const char *p, char *out) { if (!p) { errno = 22; return NULL; } if (!out) out = malloc(4096); strncpy(out, p, 4095); out[4095] = 0; return out; }
long b_readlink(const char *p, char *b, size_t n) { errno = 2; return -1; }
int b_scandir(const char *p, void *l, void *f, void *c) { errno = 2; return -1; }
int b_statvfs(const char *p, void *o) { uint64_t *v = o; memset(o, 0, 112); v[0] = 4096; v[1] = 4096; v[2] = 8ull << 20; v[3] = 4ull << 20; v[4] = 4ull << 20; v[5] = 1 << 20; v[6] = 1 << 20; v[7] = 1 << 20; v[10] = 255; return 0; }
int b_statfs(const char *p, void *o) { uint64_t *v = o; memset(o, 0, 120); v[0] = 0xEF53; v[1] = 4096; v[2] = 8ull << 20; v[3] = 4ull << 20; v[4] = 4ull << 20; v[5] = 1 << 20; v[6] = 1 << 20; return 0; }
int b_open64(const char *p, int f, ...) { return b_open(p, f, 0644); }
static void fill_stat(void *out, const struct stat *s) {   /* Linux aarch64 struct stat, 128 bytes */
  uint8_t *o = out; memset(o, 0, 128);
  #define PUT(off, T, v) do { T t_ = (T)(v); memcpy(o + (off), &t_, sizeof t_); } while (0)
  PUT(0, uint64_t, s->st_dev); PUT(8, uint64_t, s->st_ino); PUT(16, uint32_t, s->st_mode); PUT(20, uint32_t, s->st_nlink);
  PUT(24, uint32_t, s->st_uid); PUT(28, uint32_t, s->st_gid); PUT(48, int64_t, s->st_size); PUT(56, int32_t, 4096);
  PUT(64, int64_t, (s->st_size + 511) / 512); PUT(72, int64_t, s->st_atime); PUT(88, int64_t, s->st_mtime); PUT(104, int64_t, s->st_ctime);
  #undef PUT
}
int b_stat(const char *p0, void *o)  { char fb[640]; const char *p = sdpath(p0, fb); struct stat s; int r = stat(p, &s);  if (!r) fill_stat(o, &s); flog("stat", p, r); return r; }
int b_lstat(const char *p0, void *o) { char fb[640]; const char *p = sdpath(p0, fb); struct stat s; int r = stat(p, &s);  if (!r) fill_stat(o, &s); return r; }
int b_fstat(int fd, void *o)        { struct stat s; int r = fstat(fd, &s); if (!r) fill_stat(o, &s); return r; }
struct bdirent { uint64_t ino; int64_t off; uint16_t reclen; uint8_t type; char name[256]; };
void *b_readdir(void *d) {
  static __thread struct bdirent e; struct dirent *n = readdir(d); if (!n) return NULL;
  e.ino = n->d_ino; e.off = 0; e.reclen = sizeof e; 
#ifdef _DIRENT_HAVE_D_TYPE
  e.type = n->d_type == DT_DIR ? 4 : 8;
#else
  e.type = 8;
#endif
  strncpy(e.name, n->d_name, 255); e.name[255] = 0; return &e; }
int b_getpid(void) { return 1; }
int b_gettid(void) { return (int)(uintptr_t)armGetTls() & 0x7fffffff; }
int b_fcntl(int fd, int cmd, ...) { return 0; }
int b_ioctl(int fd, unsigned long r, ...) { errno = ENOTTY; return -1; }
/* mmap emulation: one big arena handed out in 4 KB pages with a bitmap, so allocators that over-allocate and munmap the head/tail
 * (to get an aligned block) or free blocks partially work. */
#define AR_PG 4096ul
static uint8_t *g_ar; static size_t g_ar_pages; static uint8_t *g_ar_map; static Mutex g_ar_mx;
static int ar_init(void) {
  if (g_ar) return 1; size_t sz = 768ul << 20;
  while (sz >= (64ul << 20)) { g_ar = memalign(1 << 20, sz); if (g_ar) break; sz >>= 1; }
  if (!g_ar) return 0; g_ar_pages = sz / AR_PG; g_ar_map = calloc(g_ar_pages, 1); jni_log("[mmap] arena %p size %zu MB", g_ar, sz >> 20); return g_ar_map != NULL; }
static void *ar_alloc(size_t len, size_t align) {
  size_t np = (len + AR_PG - 1) / AR_PG, ap = align > AR_PG ? align / AR_PG : 1; void *r = NULL;
  mutexLock(&g_ar_mx);
  static size_t hint;                                     /* next-fit: avoids rescanning the full bitmap on every mapping */
  if (ar_init()) for (int pass = 0; pass < 2 && !r; pass++) {
    size_t lo = pass ? 0 : hint, hi = pass ? hint + np : g_ar_pages; if (hi > g_ar_pages) hi = g_ar_pages;
    size_t run = 0, start = 0;
    for (size_t i = lo; i < hi; i++) {
      if (g_ar_map[i]) { run = 0; continue; }
      if (run == 0) { if ((((uintptr_t)g_ar / AR_PG) + i) % ap) continue; start = i; }
      if (++run == np) { memset(g_ar_map + start, 1, np); r = g_ar + start * AR_PG; hint = start + np; break; } } }
  mutexUnlock(&g_ar_mx); if (r) memset(r, 0, np * AR_PG); return r; }
void *b_mmap(void *a, size_t len, int prot, int fl, int fd, long off) {
  if (!len) { errno = EINVAL; return (void *)-1; }
  size_t align = len >= (2ul << 20) ? (2ul << 20) : AR_PG;
  void *p = ar_alloc(len, align);
  if (!p) { jni_log("[mmap] ARENA FULL len=%zu", len); errno = ENOMEM; return (void *)-1; }
  if (fd >= 0) {                                          /* file mapping: private copy */
    off_t sz = lseek(fd, 0, SEEK_END); jni_log("[mmap] fd=%d len=%zu off=%ld filesize=%ld -> %p", fd, len, off, (long)sz, p);
    lseek(fd, off, SEEK_SET); size_t got = 0; while (got < len) { int r = read(fd, (char *)p + got, len - got); if (r <= 0) break; got += r; } }
  return p; }
int b_munmap(void *a, size_t l) {
  uintptr_t x = (uintptr_t)a; if (!g_ar || x < (uintptr_t)g_ar || x >= (uintptr_t)g_ar + g_ar_pages * AR_PG) return 0;
  size_t i = (x - (uintptr_t)g_ar) / AR_PG, n = (l + AR_PG - 1) / AR_PG; if (i + n > g_ar_pages) n = g_ar_pages - i;
  mutexLock(&g_ar_mx); memset(g_ar_map + i, 0, n); mutexUnlock(&g_ar_mx); return 0; }
size_t ar_used_mb(void) { if (!g_ar_map) return 0; size_t n = 0; for (size_t i = 0; i < g_ar_pages; i++) n += g_ar_map[i]; return n * AR_PG >> 20; }
void b_exit(int c) { extern unsigned long long g_game_img; jni_log("[exit] exit(%d) caller=img+0x%llx", c, (unsigned long long)__builtin_return_address(0) - g_game_img); jni_log_flush(); svcExitProcess(); for (;;) svcSleepThread(1000000000ll); }
void b__exit(int c) { extern unsigned long long g_game_img; jni_log("[exit] _exit(%d) caller=img+0x%llx", c, (unsigned long long)__builtin_return_address(0) - g_game_img); jni_log_flush(); svcExitProcess(); for (;;) svcSleepThread(1000000000ll); }
int b_mprotect(void *a, size_t l, int p) { return 0; }
char *b_setlocale(int c, const char *l) { return "C"; }
void *b_newlocale(int m, const char *l, void *b) { return (void *)1; }
void *b_uselocale(void *l) { return (void *)1; }
int b_pthread_setname_np(uint64_t t, const char *n) { return 0; }
void *b_dlopen(const char *n, int f) { return (void *)1; }
void *b_dlsym(void *h, const char *n) { return imports_lookup(n); }
int b_dlclose(void *h) { return 0; }
char *b_dlerror(void) { return NULL; }
#define NOSYS(name, ...) int b_##name(__VA_ARGS__) { errno = ENOSYS; return -1; }
/* the game (and asio) use select()/poll() as a sleep: honour the timeout instead of failing instantly (a busy loop starves every other thread) */
int b_poll(void *f, unsigned long n, int t) { if (t < 0) t = 100; svcSleepThread((s64)t * 1000000ll); return 0; }
int b_select(int n, void *r, void *w, void *e, void *t) {
  s64 ns = 100000000ll; if (t) { const long long *tv = (const long long *)t; ns = tv[0] * 1000000000ll + tv[1] * 1000ll; }   /* bionic timeval: 2 x 64-bit */
  if (ns > 0) svcSleepThread(ns); else svcSleepThread(0); return 0; }
NOSYS(recv, int s, void *b, size_t l, int f) NOSYS(send, int s, const void *b, size_t l, int f)
NOSYS(recvfrom, int s, void *b, size_t l, int f, void *a, void *al) NOSYS(sendto, int s, const void *b, size_t l, int f, const void *a, unsigned al)
NOSYS(setsockopt, int s, int l, int o, const void *v, unsigned n) NOSYS(getsockopt, int s, int l, int o, void *v, void *n)
NOSYS(shutdown, int s, int h) NOSYS(bind, int s, const void *a, unsigned l) NOSYS(accept, int s, void *a, void *l)

/* pthread attributes: [0]=detach state, [8]=stack size (bionic attr is 56 bytes). Threads default to 1 MiB. */
int b_pthread_attr_init(void *a) { memset(a, 0, 56); *(uint64_t *)((uint8_t *)a + 8) = 1u << 20; return 0; }
int b_pthread_attr_destroy(void *a) { return 0; }
int b_pthread_attr_setdetachstate(void *a, int s) { *(int *)a = s; return 0; }
int b_pthread_attr_setstacksize(void *a, size_t n) { *(uint64_t *)((uint8_t *)a + 8) = n; return 0; }

/* newlib has no timegm: days-from-civil (H. Hinnant), UTC, tolerant of out-of-range tm_mon */
time_t b_timegm(struct tm *t) {
  int64_t y = (int64_t)t->tm_year + 1900 + t->tm_mon / 12; int64_t m = t->tm_mon % 12;
  if (m < 0) { m += 12; y--; }
  m += 1; y -= m <= 2;
  int64_t era = (y >= 0 ? y : y - 399) / 400, yoe = y - era * 400;
  int64_t doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + t->tm_mday - 1;
  int64_t doe = yoe * 365 + yoe / 4 - yoe / 100 + doy, days = era * 146097 + doe - 719468;
  return (time_t)(days * 86400 + (int64_t)t->tm_hour * 3600 + (int64_t)t->tm_min * 60 + t->tm_sec); }

/* newlib has memalign but no posix_memalign (alignment must be a power of two and a multiple of sizeof(void*)) */
int b_posix_memalign(void **out, size_t align, size_t size) {
  if (align < sizeof(void *) || (align & (align - 1))) return EINVAL;
  void *p = memalign(align, size ? size : 1); if (!p) return ENOMEM;
  *out = p; return 0; }

/* bionic's _ctype_ (ctype macros index it with c+1): _U 1 _L 2 _N 4 _S 8 _P 0x10 _C 0x20 _X 0x40 _B 0x80 */
char b__ctype_[257];
__attribute__((constructor)) static void ctype_init(void) {
  for (int c = 0; c < 256; c++) {
    unsigned f = 0;
    if (c >= 'A' && c <= 'Z') f |= 0x01; if (c >= 'a' && c <= 'z') f |= 0x02; if (c >= '0' && c <= '9') f |= 0x04;
    if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')) f |= 0x40;
    if (c == ' ') f |= 0x08 | 0x80; if (c >= 9 && c <= 13) f |= 0x08;
    if (c < 32 || c == 127) f |= 0x20;
    if (c > 32 && c < 127 && !(f & 0x07)) f |= 0x10;
    b__ctype_[c + 1] = (char)f; } }


/* ---- string formatting, errors, syscalls, unwinding support ------------------------------------ */
int b_vasprintf(char **out, const char *fmt, va_list ap) {
  va_list c; va_copy(c, ap); int n = vsnprintf(NULL, 0, fmt, c); va_end(c);
  if (n < 0) { *out = NULL; return -1; }
  char *p = malloc((size_t)n + 1); if (!p) { *out = NULL; return -1; }
  vsnprintf(p, (size_t)n + 1, fmt, ap); *out = p; return n; }
int b_asprintf(char **out, const char *fmt, ...) { va_list a; va_start(a, fmt); int r = b_vasprintf(out, fmt, a); va_end(a); return r; }
int b_strerror_r(int e, char *buf, size_t n) { if (buf && n) snprintf(buf, n, "%s", strerror(e)); return 0; }   /* XSI form, as bionic */
int b___ctype_get_mb_cur_max(void) { return 1; }
void *b_OPENSSL_memory_alloc(size_t n) { return malloc(n); }
void b_OPENSSL_memory_free(void *p) { free(p); }
size_t b_OPENSSL_memory_get_size(void *p) { extern size_t malloc_usable_size(void *); return p ? malloc_usable_size(p) : 0; }

/* the game's own C++ unwinder asks which modules exist and where their program headers are */
static uintptr_t g_mod_base; static uint64_t g_mod_phoff; static unsigned g_mod_phnum;
void shim_set_module(uintptr_t base, uint64_t phoff, unsigned phnum) { g_mod_base = base; g_mod_phoff = phoff; g_mod_phnum = phnum; }
struct bdl_info { uint64_t addr; const char *name; const void *phdr; uint16_t phnum; uint16_t pad[3];
                  uint64_t adds, subs; size_t tls_modid; void *tls_data; };
int b_dl_iterate_phdr(int (*cb)(struct bdl_info *, size_t, void *), void *data) {
  if (!g_mod_base || !cb) return 0;
  struct bdl_info i; memset(&i, 0, sizeof i);
  i.addr = g_mod_base; i.name = "libAsphalt8.so"; i.phdr = (const void *)(g_mod_base + g_mod_phoff); i.phnum = (uint16_t)g_mod_phnum;
  return cb(&i, sizeof i, data); }

/* syscall(2): the numbers are Linux/arm64's. Only what a game plausibly uses; the rest fail with ENOSYS and are logged. */
long b_syscall(long nr, ...) {
  va_list a; va_start(a, nr);
  long r = -1;
  switch (nr) {
    case 178: r = b_gettid(); break;                                         /* gettid */
    case 172: r = 1; break;                                                  /* getpid */
    case 124: svcSleepThread(0); r = 0; break;                               /* sched_yield */
    case 278: { void *buf = va_arg(a, void *); size_t n = va_arg(a, size_t); randomGet(buf, n); r = (long)n; break; }   /* getrandom */
    case 113: { int clk = va_arg(a, int); struct timespec *ts = va_arg(a, struct timespec *); r = b_clock_gettime(clk, ts); break; }
    case 98: {                                                               /* futex(uaddr, op, val, timeout) */
      int *uaddr = va_arg(a, int *); int op = va_arg(a, int) & 127; int val = va_arg(a, int);
      const struct timespec *to = va_arg(a, const struct timespec *);
      if (op == 0 || op == 9) {                                              /* FUTEX_WAIT / WAIT_BITSET */
        if (__atomic_load_n(uaddr, __ATOMIC_SEQ_CST) != val) { errno = EAGAIN; r = -1; break; }
        s64 ns = to ? (s64)to->tv_sec * 1000000000ll + to->tv_nsec : -1;
        Result rc = svcWaitForAddress(uaddr, ArbitrationType_WaitIfEqual, val, ns);
        if (R_FAILED(rc)) { errno = to ? 110 : EAGAIN; r = -1; } else r = 0;
      } else if (op == 1 || op == 10) {                                      /* FUTEX_WAKE / WAKE_BITSET */
        svcSignalToAddress(uaddr, SignalType_Signal, 0, val > 0 ? val : -1); r = val > 0 ? val : 1;
      } else { errno = ENOSYS; r = -1; }
      break; }
    default: { static int n; if (n++ < 20) jni_log("syscall(%ld) not supported", nr); errno = ENOSYS; r = -1; } }
  va_end(a); return r; }

/* more small libc pieces the engine links against */
int b_fstat64(int fd, void *o) { return b_fstat(fd, o); }
int b_stat64(const char *p, void *o) { return b_stat(p, o); }
int b_lstat64(const char *p, void *o) { return b_lstat(p, o); }
int b_fdatasync(int fd) { return fsync(fd); }
int b_chmod(const char *p, unsigned m) { return 0; }
int b_fchmod(int fd, unsigned m) { return 0; }
int b_chown(const char *p, unsigned u, unsigned g) { return 0; }
int b_flock(int fd, int op) { return 0; }
int b_clock_getres(int clk, struct timespec *r) { if (r) { r->tv_sec = 0; r->tv_nsec = 1; } return 0; }
long b_clock(void) { struct timespec t; b_clock_gettime(1, &t); return (long)t.tv_sec * 1000000 + t.tv_nsec / 1000; }
int b_getentropy(void *buf, size_t n) { randomGet(buf, n); return 0; }
unsigned b_getuid(void) { return 1000; } unsigned b_geteuid(void) { return 1000; }
unsigned b_getgid(void) { return 1000; } unsigned b_getegid(void) { return 1000; }
int b_dladdr(const void *a, void *info) { return 0; }
/* data symbols */
static char *g_environ_arr[1] = { 0 };
char **b_environ = g_environ_arr;                       /* an empty environment */
int b_daylight = 0;


/* GL_OES_mapbuffer is missing from Mesa's GLES3: emulate through the core GLES3 entry points. */
extern void *glMapBufferRange(unsigned target, long offset, long length, unsigned access);
extern unsigned char glUnmapBuffer(unsigned target);
extern void glGetBufferParameteriv(unsigned target, unsigned pname, int *params);
void *b_glMapBufferOES(unsigned target, unsigned access) {
  int sz = 0; glGetBufferParameteriv(target, 0x8764 /*GL_BUFFER_SIZE*/, &sz);
  void *p = sz > 0 ? glMapBufferRange(target, 0, sz, 0x000A /*WRITE|INVALIDATE_BUFFER*/) : NULL;
  { static int n; if (n++ < 5) jni_log("glMapBufferOES(0x%x,0x%x) size=%d -> %p", target, access, sz, p); } return p;
}
unsigned char b_glUnmapBufferOES(unsigned target) { return glUnmapBuffer(target); }

#include <math.h>
void b_sincosf(float x, float *s, float *c) { *s = sinf(x); *c = cosf(x); }
void b_sincos(double x, double *s, double *c) { *s = sin(x); *c = cos(x); }
long long b_lseek64(int fd, long long off, int wh) { return (long long)lseek(fd, (off_t)off, wh); }
char *b_strerror(int e) { return strerror(e); }
unsigned long long b_strtoull_l(const char *s, char **e, int b, void *loc) { return strtoull(s, e, b); }
long long b_strtoll_l(const char *s, char **e, int b, void *loc) { return strtoll(s, e, b); }

static Mutex g_pr_mx;
long b_pread(int fd, void *buf, size_t n, long off) {
  mutexLock(&g_pr_mx); long cur = lseek(fd, 0, SEEK_CUR); lseek(fd, off, SEEK_SET); long r = read(fd, buf, n); lseek(fd, cur, SEEK_SET); mutexUnlock(&g_pr_mx);
  static int c; if (c < 60) { c++; jni_log("[pread] fd=%d n=%zu off=%ld -> %ld", fd, n, off, r); } return r; }
long b_pread64(int fd, void *buf, size_t n, long off) { return b_pread(fd, buf, n, off); }

size_t b_fread(void *p, size_t a, size_t n, void *f) { if (!f) return 0; return fread(p, a, n, fx(f)); }
int b_fclose(void *f) { if (!f) return -1; return fclose(fx(f)); }
int b_fseek(void *f, long o, int w) { if (!f) return -1; return fseek(fx(f), o, w); }
long b_ftell(void *f) { if (!f) return -1; return ftell(fx(f)); }
void b_rewind(void *f) { if (f) rewind(fx(f)); }

void b_pthread_exit(void *r) { extern unsigned long long g_game_img; jni_log("[thread] pthread_exit by game, caller=img+0x%llx", (unsigned long long)__builtin_return_address(0) - g_game_img); pthread_exit(r); }

size_t b_malloc_usable_size(void *p) { extern size_t malloc_usable_size(void *); return p ? malloc_usable_size(p) : 0; }
void b_sdallocx(void *p, size_t sz, int fl) { free(p); }
