/* game.c -- drives the engine after JNI_OnLoad: setPaths/init, EGL window+context, initGL, resize, then
 * step()+swap per frame; touch screen -> touchEvent. Everything is logged to debug.log. */
#include <stdalign.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <switch.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <malloc.h>
#include "game.h"
#include "jni_fake.h"

#define ROOT "/switch/a8nx64"
#define CLS "Java_com_gameloft_android_ANMP_GloftA8HM_GL2JNILib_"
#define BRG "Java_com_gameloft_android_ANMP_GloftA8HM_PackageUtils_JNIBridge_"
typedef void (*f_v)(void *, void *);
typedef void (*f_o)(void *, void *, void *);
typedef void (*f_z)(void *, void *, int);
typedef void (*f_ii)(void *, void *, int, int);
typedef void (*f_iiii)(void *, void *, int, int, int, int);
typedef void (*f_ooo)(void *, void *, void *, void *, void *);

extern void *g_main_tls; extern EGLSurface g_main_surf; extern EGLConfig g_main_cfg;
static so_mod *M; static void (*g_ontouch)(void *, void *, int, float, float, int); unsigned long long g_game_img;
extern void *g_thr_tls[64]; extern int g_nthr; extern unsigned g_thr_h[64]; extern unsigned long long g_thr_fn[64];

static void *sym(const char *n) { void *p = so_sym(M, n); if (!p) jni_log("MISSING native %s", n); return p; }
#define NAT(n) sym(CLS n)


/* A fault in a game worker thread must not take the whole process down: log it to exception.log (big exception stack so
 * stdio works) and end just that thread. A fault on the main thread ends the process. */
alignas(16) u8 __nx_exception_stack[0x20000]; u64 __nx_exception_stack_size = sizeof(__nx_exception_stack);
static FILE *g_exf; static volatile int g_nfault; static unsigned long long g_img;
void __libnx_exception_handler(ThreadExceptionDump *ctx) {
  int main_thr = (armGetTls() == g_main_tls);
  int i = __atomic_fetch_add(&g_nfault, 1, __ATOMIC_SEQ_CST);
  if (g_exf && i < 40) {
    fprintf(g_exf, "[exception] #%d %s thread: error=%u pc=0x%llx (img+0x%llx) lr=0x%llx (img+0x%llx) sp=0x%llx far=0x%llx esr=0x%x\n",
            i, main_thr ? "MAIN" : "worker", (unsigned)ctx->error_desc, (unsigned long long)ctx->pc.x, (unsigned long long)ctx->pc.x - g_img,
            (unsigned long long)ctx->lr.x, (unsigned long long)ctx->lr.x - g_img, (unsigned long long)ctx->sp.x,
            (unsigned long long)ctx->far.x, (unsigned)ctx->esr);
    for (int r = 0; r < 29; r++) fprintf(g_exf, " x%d=0x%llx", r, (unsigned long long)ctx->cpu_gprs[r].x);
    fprintf(g_exf, "\n");
    { void *me = armGetTls(); for (int k = 0; k < 64; k++) if (g_thr_tls[k] == me) fprintf(g_exf, " thread #%d fn=img+0x%llx\n", k, g_thr_fn[k]); }
    { unsigned long long b = ctx->cpu_gprs[19].x;
      if (b > 0x100000000ull && b < 0x7000000000ull) {
        MemoryInfo mi; u32 pi; unsigned long long lo = b - 0x40;
        if (R_SUCCEEDED(svcQueryMemory(&mi, &pi, lo)) && mi.perm == Perm_Rw && lo + 0xd40 <= mi.addr + mi.size) {
          extern size_t malloc_usable_size(void *);
          fprintf(g_exf, " [dump] x19 usable=%zu\n", malloc_usable_size((void *)b));
          for (unsigned long long a = lo; a < b + 0x80; a += 16) fprintf(g_exf, " [d] %+lld: %016llx %016llx\n", (long long)(a - b), *(u64 *)a, *(u64 *)(a + 8));
          for (unsigned long long a = b + 0xb60; a < b + 0xc50; a += 16) fprintf(g_exf, " [d] +%llx: %016llx %016llx\n", a - b, *(u64 *)a, *(u64 *)(a + 8));
        }
      } }
    fflush(g_exf);
  }
  if (main_thr) svcExitProcess();
  svcExitThread();
  for (;;) svcSleepThread(1000000000ll);
}


/* diagnostic: every 3 s dump where each game thread is (pc/lr + game-code return addresses found on its stack, as image
 * offsets). Threads are paused only while their registers/stack are copied; logging happens after they all run again
 * (a paused thread may hold the log lock). */
static Thread g_samp_thr; static unsigned g_main_h;
static char g_sl[66][420];
static void snap(char *out, unsigned h) {
  out[0] = 0; if (!h) return; if (R_FAILED(svcSetThreadActivity(h, ThreadActivity_Paused))) { strcpy(out, "(cannot pause)"); return; }
  ThreadContext c; if (R_SUCCEEDED(svcGetThreadContext3(&c, h))) {
    unsigned long long pc = c.pc.x, lr = c.lr, sp = c.sp, lo = g_img, hi = g_img + 0x2b19000;
    int n = snprintf(out, 420, "pc=%llx lr=%llx |", pc >= lo && pc < hi ? pc - lo : pc, lr >= lo && lr < hi ? lr - lo : lr);
    int found = 0; const unsigned long long *w = (const unsigned long long *)sp; int maxw = 0;
    { MemoryInfo mi; u32 pi; if (R_SUCCEEDED(svcQueryMemory(&mi, &pi, sp)) && (mi.perm & 1) && sp >= mi.addr) { unsigned long long left = mi.addr + mi.size - sp; maxw = left / 8 > 160 ? 160 : (int)(left / 8); } }
    for (int i = 0; i < maxw && found < 10 && n < 380; i++) { unsigned long long v = w[i]; if (v >= lo && v < hi && !(v & 3)) { n += snprintf(out + n, 420 - n, " %llx", v - lo); found++; } } }
  svcSetThreadActivity(h, ThreadActivity_Runnable); }
static void sampler(void *a) {
    for (int round = 0; round < 10; round++) { svcSleepThread(3000000000ll);
    int cnt = g_nthr < 64 ? g_nthr : 64; snap(g_sl[64], g_main_h);
    for (int i = 0; i < cnt; i++) snap(g_sl[i], g_thr_h[i]);
    jni_log("[sample] ---- round %d, %d threads", round, cnt); jni_log("[sample] main: %s", g_sl[64]);
    for (int i = 0; i < cnt; i++) if (g_sl[i][0]) jni_log("[sample] t%d(fn=%llx): %s", i, g_thr_fn[i], g_sl[i]); } }

static int fatal(const char *msg) { jni_log("FATAL: %s", msg); consoleInit(NULL); printf("%s\nsee debug.log\n", msg); consoleUpdate(NULL); svcSleepThread(5000000000ll); consoleExit(NULL); return 1; }

int game_run(so_mod *m) {
  M = m; g_main_tls = armGetTls(); g_img = (unsigned long long)m->rx; g_game_img = g_img;
  freopen(ROOT "/stdout.log", "w", stdout); setvbuf(stdout, NULL, _IOLBF, 0);   /* console is gone: game printf -> file */
  freopen(ROOT "/stderr.log", "w", stderr);
  g_exf = fopen(ROOT "/exception.log", "w"); if (g_exf) setvbuf(g_exf, NULL, _IONBF, 0);
  g_main_h = threadGetCurHandle();
  if (0 && R_SUCCEEDED(threadCreate(&g_samp_thr, sampler, NULL, NULL, 0x4000, 0x2c, -2))) threadStart(&g_samp_thr);
  void *env = jni_fake_env(), *cls = "com/gameloft/android/ANMP/GloftA8HM/GL2JNILib", *ctx = "android/content/Context";
  mkdir(ROOT, 0777); mkdir(ROOT "/data", 0777); mkdir(ROOT "/data/files", 0777); mkdir(ROOT "/data/cache", 0777);
  chdir(ROOT "/data");
  mkdir(ROOT "/assets", 0777); mkdir(ROOT "/assetpacks", 0777);

  f_ooo set_paths = NAT("setPaths");
  if (set_paths) { jni_log("setPaths"); set_paths(env, cls, ROOT "/data", ROOT "/data/files", ROOT "/data/cache"); jni_log("setPaths done"); }
  f_o set_act = sym(BRG "SetActivity");
  if (set_act) { jni_log("JNIBridge.SetActivity"); set_act(env, "com/gameloft/android/ANMP/GloftA8HM/PackageUtils/JNIBridge", "android/app/Activity"); }
  f_v bnit = sym(BRG "NativeInit");
  if (bnit) { jni_log("JNIBridge.NativeInit"); bnit(env, "com/gameloft/android/ANMP/GloftA8HM/PackageUtils/JNIBridge"); jni_log("NativeInit done"); svcSleepThread(3000000000ll); jni_log("settled after NativeInit"); }
  f_o init = NAT("init");
  if (init) { jni_log("GL2JNILib.init"); init(env, cls, ctx); jni_log("GL2JNILib.init done"); }

  /* ---- EGL ---- */
  NWindow *win = nwindowGetDefault();
  nwindowSetDimensions(win, 1280, 720);
  EGLDisplay dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
  EGLint maj = 0, min = 0;
  if (!eglInitialize(dpy, &maj, &min)) return fatal("eglInitialize failed");
  jni_log("EGL %d.%d", maj, min);
  eglBindAPI(EGL_OPENGL_ES_API);


  EGLConfig cfg = NULL; EGLint n = 0;
  EGLint a1[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_STENCIL_SIZE, 8, EGL_NONE};
  EGLint a2[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 16, EGL_NONE};
  if (!eglChooseConfig(dpy, a1, &cfg, 1, &n) || n < 1) { jni_log("config 24/8 not found"); if (!eglChooseConfig(dpy, a2, &cfg, 1, &n) || n < 1) return fatal("no EGL config"); }
  EGLSurface surf = eglCreateWindowSurface(dpy, cfg, win, NULL);
  if (!surf) { jni_log("eglCreateWindowSurface err 0x%x", eglGetError()); return fatal("no EGL surface"); }
  g_main_surf = surf; g_main_cfg = cfg;
  int ver = 3; EGLContext ec = EGL_NO_CONTEXT;
  for (; ver >= 2 && ec == EGL_NO_CONTEXT; ver--) {
    EGLint ca[] = {EGL_CONTEXT_CLIENT_VERSION, ver, EGL_NONE};
    ec = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, ca);
    jni_log("eglCreateContext GLES%d -> %p (err 0x%x)", ver, ec, eglGetError()); }
  ver++;
  if (ec == EGL_NO_CONTEXT) return fatal("no EGL context");
  if (!eglMakeCurrent(dpy, surf, surf, ec)) return fatal("eglMakeCurrent failed");
  jni_log("GL_VERSION %s | GL_RENDERER %s", (const char *)glGetString(0x1F02), (const char *)glGetString(0x1F01));
  f_v init_gl = NAT("initGL"), view_settings = NAT("getViewSettings");
  if (view_settings) { jni_log("getViewSettings"); view_settings(env, cls); }
  if (init_gl) { jni_log("initGL (context current)"); init_gl(env, cls); jni_log("initGL done glerr=0x%x", glGetError()); }
  eglMakeCurrent(dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);   /* free window/context: the engine makes its own current on its render thread */
  f_o setver = sym("Java_com_gameloft_android_ANMP_GloftA8HM_MainActivity_setOpenGlesVersion");
  if (setver) ((void (*)(void *, void *, int))setver)(env, "com/gameloft/android/ANMP/GloftA8HM/MainActivity", ver);

  f_z state = NAT("stateChanged"); f_ii resize = NAT("resize"); f_v step = NAT("step"); f_iiii touch = NAT("touchEvent");
  if (!state || !resize || !step) return fatal("GL2JNILib natives missing");
  eglSwapInterval(dpy, 1);
  const char *B = "com/gameloft/android/ANMP/GloftA8HM/PackageUtils/JNIBridge";
  typedef void (*f_oii)(void *, void *, void *, int, int);
  f_oii surf_ch = sym(BRG "NativeSurfaceChanged");
  if (surf_ch) { jni_log("NativeSurfaceChanged"); surf_ch(env, (void *)B, "android/view/Surface", 1280, 720); svcSleepThread(3000000000ll); jni_log("settled after surface"); }
  f_v onres = NAT("onResume"); if (onres) { jni_log("GL2JNILib.onResume"); onres(env, cls); }
  f_v bres = sym(BRG "NativeOnResume"); if (bres) { jni_log("JNIBridge.NativeOnResume"); bres(env, (void *)B); }
  { typedef void (*f_i)(void *, void *, int); typedef void (*f_zzzi)(void *, void *, int, int, int, int);
    f_i sct = sym(BRG "SetConnectionType"); if (sct) { jni_log("JNIBridge.SetConnectionType(0)"); sct(env, (void *)B, 0); }
    f_zzzi sbi = sym(BRG "SetBatteryInfo"); if (sbi) { jni_log("JNIBridge.SetBatteryInfo"); sbi(env, (void *)B, 0, 1, 0, 100); } }
  svcSleepThread(2000000000ll); jni_log("stateChanged(1)"); state(env, cls, 1); svcSleepThread(2000000000ll);
  jni_log("resize 1280x720"); resize(env, cls, 1280, 720);
  { typedef int (*f_i)(void *, void *); typedef void (*f_s)(void *, void *, int);
    f_i gne = NAT("getNumExtraContext"); if (gne) jni_log("getNumExtraContext -> %d", gne(env, cls));
    f_s ori = NAT("orientationChanged"); if (ori) ori(env, cls, 1);
    f_z saf = NAT("nativeSetStatusSafeZone"); if (saf) saf(env, cls, 0);
    typedef int (*f_chk)(void *, void *, int); f_chk chk = NAT("nativeCheckGLVersionGPU"); if (chk) jni_log("nativeCheckGLVersionGPU(3) -> %d", chk(env, cls, 3)); }
  f_v odr = sym(BRG "OnDeviceResolutionChanged"); if (odr) { jni_log("OnDeviceResolutionChanged"); odr(env, (void *)B); }
  { typedef void (*f_tt)(void *, void *, int, float, float, int); g_ontouch = (f_tt)sym(BRG "NativeOnTouch"); }
  eglMakeCurrent(dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);   /* the engine runs its own render thread and EGL */
  jni_log("entering idle loop (engine renders on its own threads; main thread only handles input)");

  padConfigureInput(1, HidNpadStyleSet_NpadStandard); PadState pad; padInitializeDefault(&pad);
  hidInitializeTouchScreen();
  int prev = 0; HidTouchState last = {0};
  for (unsigned long fr = 0; appletMainLoop(); fr++) {
    padUpdate(&pad);
    if (padGetButtonsDown(&pad) & HidNpadButton_Plus) { jni_log("exit requested (+)"); break; }
    HidTouchScreenState ts = {0};
    if (hidGetTouchScreenStates(&ts, 1) && ts.count > 0) {
      HidTouchState t = ts.touches[0];
      if (g_ontouch) g_ontouch(env, (void *)B, prev ? 2 : 0, (float)t.x, (float)t.y, 0); prev = 1; last = t; }
    else if (prev) { if (g_ontouch) g_ontouch(env, (void *)B, 1, (float)last.x, (float)last.y, 0); prev = 0; }
    if (fr % 60 == 0) { extern volatile unsigned g_swaps; static unsigned last; static int boosted; unsigned d = g_swaps - last; last = g_swaps;
      int want = d < 20;                                   /* slow frames = loading: CPU boost (FastLoad); real frames: normal clocks for the GPU */
      if (want != boosted) { boosted = want; appletSetCpuBoostMode(want ? ApmCpuBoostMode_FastLoad : ApmCpuBoostMode_Normal); }
      jni_log("fps~%u boost=%d", d, boosted); }
    if (fr % 60 == 0) { extern int g_egl_stats[]; { extern unsigned long long g_io_bytes, g_io_calls; jni_log_flush(); { u64 um = 0, tm = 0; svcGetInfo(&um, InfoType_UsedMemorySize, CUR_PROCESS_HANDLE, 0); svcGetInfo(&tm, InfoType_TotalMemorySize, CUR_PROCESS_HANDLE, 0); { struct mallinfo mi = mallinfo(); jni_log("mem used=%llu MB total=%llu MB malloc=%d MB arena=%d MB", um >> 20, tm >> 20, (int)(mi.uordblks >> 20), (int)(mi.arena >> 20)); } } jni_log("frame %lu mc_ok=%d mc_fail=%d io_read=%llu MB in %llu calls", fr, g_egl_stats[0], g_egl_stats[1], g_io_bytes >> 20, g_io_calls); } }
    svcSleepThread(16000000ll);
  }
  state(env, cls, 0);
  f_v destroy = NAT("destroy"); if (destroy) destroy(env, cls);
  jni_log("game_run end"); jni_log_flush(); { extern volatile int g_log_off; g_log_off = 1; } svcExitProcess(); return 0;
  return 0;
}
