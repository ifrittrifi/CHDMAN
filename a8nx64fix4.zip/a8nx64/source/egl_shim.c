/* egl_shim.c -- the engine's own EGL calls: logged, validated, and mapped onto the window/surface that
 * game.c already created (the Switch has exactly one window). */
#include <stdint.h>
#include <stddef.h>
#include <EGL/egl.h>
#include <switch.h>
#include "jni_fake.h"

void *g_main_tls; int g_egl_stats[2];
EGLSurface g_main_surf; EGLConfig g_main_cfg;                         /* set by game.c */
static int n_calls;
#define LOG(...) do { if (n_calls++ < 400) jni_log(__VA_ARGS__); } while (0)

EGLDisplay b_eglGetDisplay(void *d) { EGLDisplay r = eglGetDisplay(EGL_DEFAULT_DISPLAY); LOG("[egl] eglGetDisplay -> %p", r); return r; }
EGLBoolean b_eglInitialize(EGLDisplay d, EGLint *a, EGLint *b) { EGLBoolean r = d ? eglInitialize(d, a, b) : 0; LOG("[egl] eglInitialize(%p) -> %d", d, r); return r; }
EGLBoolean b_eglTerminate(EGLDisplay d) { LOG("[egl] eglTerminate ignored"); return 1; }
/* Three configs are offered. The engine matches R,G,B,A EXACTLY against the colour depth of its own
 * settings (8888 / 8880 / 5650); the Switch only has 8888 EGL configs, so the 888 and 565 entries are
 * placeholders that report those channel sizes and map to the real config everywhere else. */
static char g_fake[2];                           /* &g_fake[0] = 8,8,8,0   &g_fake[1] = 5,6,5,0 */
static EGLConfig real_cfg(EGLConfig c) { return (c == (EGLConfig)&g_fake[0] || c == (EGLConfig)&g_fake[1]) ? g_main_cfg : c; }
EGLBoolean b_eglChooseConfig(EGLDisplay d, const EGLint *at, EGLConfig *c, EGLint n, EGLint *num) {
  /* (Mesa's own config sorting jumps through an undefined weak symbol in this static build: never use it.) */
  if (!d || !g_main_cfg) { if (num) *num = 0; return 0; }
  EGLConfig all[3] = { g_main_cfg, (EGLConfig)&g_fake[0], (EGLConfig)&g_fake[1] };
  int k = (c && n > 0) ? (n < 3 ? n : 3) : 3;
  if (c) for (int i = 0; i < k; i++) c[i] = all[i];
  if (num) *num = k;
  LOG("[egl] eglChooseConfig(%p) -> %d configs", d, k); return 1; }
EGLBoolean b_eglGetConfigAttrib(EGLDisplay d, EGLConfig c, EGLint a, EGLint *v) {
  if (!d || !c) { LOG("[egl] eglGetConfigAttrib(%p,%p,0x%x) rejected", d, c, a); if (v) *v = 0; return 0; }
  if ((c == (EGLConfig)&g_fake[0] || c == (EGLConfig)&g_fake[1]) && a >= 0x3021 && a <= 0x3024) {
    int f565 = (c == (EGLConfig)&g_fake[1]);
    if (v) *v = a == 0x3024 ? (f565 ? 5 : 8) : a == 0x3023 ? (f565 ? 6 : 8) : a == 0x3022 ? (f565 ? 5 : 8) : 0;
    return 1; }
  EGLBoolean r = eglGetConfigAttrib(d, real_cfg(c), a, v);
  static int na; if (na++ < 120) jni_log("[egl] eglGetConfigAttrib(cfg=%p, 0x%x) = %d -> %d", c, a, v ? *v : -1, r);
  return r; }
EGLContext b_eglCreateContext(EGLDisplay d, EGLConfig c, EGLContext s, const EGLint *at) {
  EGLContext r = (d && c) ? eglCreateContext(d, real_cfg(c), s, at) : EGL_NO_CONTEXT; LOG("[egl] eglCreateContext -> %p", r); return r; }
EGLBoolean b_eglDestroyContext(EGLDisplay d, EGLContext c) { LOG("[egl] eglDestroyContext %p", c); return d && c ? eglDestroyContext(d, c) : 0; }
EGLSurface b_eglCreateWindowSurface(EGLDisplay d, EGLConfig c, void *w, const EGLint *at) { LOG("[egl] eglCreateWindowSurface -> main surface %p", g_main_surf); return g_main_surf; }
static char g_pbfake[256];                              /* Mesa on Switch has no pbuffers: hand out fake ones, contexts run surfaceless */
static int is_pb(EGLSurface s) { return (char *)s >= g_pbfake && (char *)s < g_pbfake + sizeof g_pbfake; }
EGLSurface b_eglCreatePbufferSurface(EGLDisplay d, EGLConfig c, const EGLint *at) {
  static int n; int i = __atomic_fetch_add(&n, 1, __ATOMIC_SEQ_CST) % 256; EGLSurface r = (EGLSurface)&g_pbfake[i];
  LOG("[egl] eglCreatePbufferSurface -> fake %p", r); return r; }
EGLBoolean b_eglDestroySurface(EGLDisplay d, EGLSurface s) { if (s == g_main_surf || is_pb(s)) return 1; return d && s ? eglDestroySurface(d, s) : 0; }
static EGLSurface thread_pbuffer(EGLDisplay d) {       /* 1x1 pbuffer per engine thread (the window belongs to the main thread) */
  static EGLSurface pb[64]; static void *own[64]; static int n; void *me = armGetTls();
  for (int i = 0; i < n; i++) if (own[i] == me) return pb[i];
  EGLint pa[] = {EGL_WIDTH, 1, EGL_HEIGHT, 1, EGL_NONE}; EGLSurface s = eglCreatePbufferSurface(d, g_main_cfg, pa);
  if (n < 64) { own[n] = me; pb[n++] = s; } return s; }
EGLBoolean b_eglMakeCurrent(EGLDisplay d, EGLSurface dr, EGLSurface rd, EGLContext c) {
  if (!d) return 0;
  if (is_pb(dr)) dr = EGL_NO_SURFACE; if (is_pb(rd)) rd = EGL_NO_SURFACE;
  EGLBoolean r = eglMakeCurrent(d, dr, rd, c); EGLint e = r ? 0x3000 : eglGetError();
  g_egl_stats[r ? 0 : 1]++;
  { extern unsigned long long g_game_img; LOG("[egl] eglMakeCurrent(draw=%p read=%p ctx=%p) -> %d err=0x%x caller=img+0x%llx", dr, rd, c, r, e, (unsigned long long)__builtin_return_address(0) - g_game_img); } return r; }
EGLBoolean b_eglSwapBuffers(EGLDisplay d, EGLSurface s) {
  static int n; int i = __atomic_fetch_add(&n, 1, __ATOMIC_SEQ_CST);
  if (is_pb(s)) return 1; EGLBoolean r = d && s ? eglSwapBuffers(d, s) : 0;
  if (i < 5 || i % 300 == 0) LOG("[egl] eglSwapBuffers #%d surf=%p -> %d err=0x%x", i, s, r, r ? 0x3000 : eglGetError()); return r; }
EGLBoolean b_eglQuerySurface(EGLDisplay d, EGLSurface s, EGLint a, EGLint *v) {
  if (a == EGL_WIDTH) { if (v) *v = 1280; return 1; } if (a == EGL_HEIGHT) { if (v) *v = 720; return 1; }
  if (is_pb(s)) { if (v) *v = 1; return 1; }
  return d && s ? eglQuerySurface(d, s, a, v) : 0; }
const char *b_eglQueryString(EGLDisplay d, EGLint n) { return eglQueryString(d, n); }
EGLContext b_eglGetCurrentContext(void) { return eglGetCurrentContext(); }
EGLint b_eglGetError(void) { return eglGetError(); }
void *b_eglGetProcAddress(const char *n) { return (void *)eglGetProcAddress(n); }
